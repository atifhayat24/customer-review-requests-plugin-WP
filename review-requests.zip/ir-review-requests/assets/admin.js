/* IR Review Requests – admin behaviour. No dependencies. */
( function () {
	'use strict';

	// Confirm before destructive actions.
	document.addEventListener( 'submit', function ( e ) {
		var form = e.target;
		if ( form && form.getAttribute && form.getAttribute( 'data-irr-confirm' ) ) {
			if ( ! window.confirm( form.getAttribute( 'data-irr-confirm' ) ) ) {
				e.preventDefault();
			}
		}
	}, true );

	// Only show SMTP fields when SMTP is selected.
	function toggleSmtp() {
		var checked = document.querySelector( 'input[data-irr-mode]:checked' );
		var isSmtp = checked && checked.value === 'smtp';
		document.querySelectorAll( 'tr.irr-smtp' ).forEach( function ( row ) {
			row.classList.toggle( 'irr-hidden', ! isSmtp );
		} );
	}
	document.querySelectorAll( 'input[data-irr-mode]' ).forEach( function ( input ) {
		input.addEventListener( 'change', toggleSmtp );
	} );
	toggleSmtp();

	// Suggest the usual port when encryption changes.
	var enc = document.querySelector( 'select[name="irr2_settings[smtp_encryption]"]' );
	var port = document.getElementById( 'irr_smtp_port' );
	if ( enc && port ) {
		enc.addEventListener( 'change', function () {
			var map = { ssl: '465', tls: '587', none: '25' };
			if ( map[ enc.value ] ) {
				port.value = map[ enc.value ];
			}
		} );
	}
}() );
