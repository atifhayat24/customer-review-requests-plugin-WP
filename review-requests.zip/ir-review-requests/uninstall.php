<?php
/**
 * Runs when the plugin is deleted from the Plugins screen.
 * Data is only removed if "Delete all data on uninstall" is ticked in Settings → Data.
 *
 * @package IR_Review_Requests
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Always stop the background runner.
if ( function_exists( 'as_unschedule_all_actions' ) ) {
	as_unschedule_all_actions( 'irr2_process_queue' );
}
wp_clear_scheduled_hook( 'irr2_process_queue' );

$irr_settings = get_option( 'irr2_settings' );
if ( ! is_array( $irr_settings ) || empty( $irr_settings['delete_data'] ) || 'yes' !== $irr_settings['delete_data'] ) {
	return;
}

global $wpdb;
foreach ( array( 'irr2_queue', 'irr2_events', 'irr2_optouts' ) as $irr_table ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . $irr_table ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.NotPrepared
}
foreach ( array( 'irr2_settings', 'irr2_db_version', 'irr2_migrated', 'irr2_last_run', 'irr2_last_run_source', 'irr2_lock', 'irr2_version', 'irr2_next_due', 'irr2_backfill', 'irr2_backfill_active' ) as $irr_option ) {
	delete_option( $irr_option );
}
delete_transient( 'irr2_runner_checked' );
delete_transient( 'irr2_cleanup' );
