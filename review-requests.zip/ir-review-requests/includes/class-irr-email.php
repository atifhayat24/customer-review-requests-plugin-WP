<?php
/**
 * Builds the review request / reminder email.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_Email {

	/**
	 * @param string        $type  'request' or 'reminder'.
	 * @param WC_Order|null $order Order (null = sample data).
	 * @param string        $token Queue token for tracking / unsubscribe ('' = direct links, no unsubscribe header).
	 * @return array|WP_Error { subject, html, text, unsub_url }
	 */
	public static function build( $type, $order = null, $token = '' ) {
		$s        = IRR_Settings::all();
		$reminder = ( 'reminder' === $type );
		$track    = $token && 'yes' === $s['track_clicks'];

		$first = 'there';
		$vars  = array(
			'{first_name}'   => 'Sarah',
			'{last_name}'    => 'Smith',
			'{order_number}' => '1234',
			'{order_date}'   => wp_date( get_option( 'date_format' ) ),
			'{site_name}'    => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
		if ( $order instanceof WC_Order ) {
			$first = $order->get_billing_first_name() ? $order->get_billing_first_name() : 'there';
			$date  = $order->get_date_created();
			$vars  = array_merge( $vars, array(
				'{first_name}'   => $first,
				'{last_name}'    => $order->get_billing_last_name(),
				'{order_number}' => $order->get_order_number(),
				'{order_date}'   => $date ? wc_format_datetime( $date ) : '',
			) );
		} else {
			$first = 'Sarah';
		}

		// Links.
		$buttons = array();
		foreach ( IRR_Settings::platforms() as $key => $p ) {
			$buttons[] = array(
				'label' => str_replace( '{platform}', $p['label'], $s['button_text'] ),
				'url'   => $track ? self::click_url( $token, $key ) : $p['url'],
			);
		}

		$products = array();
		if ( 'yes' === $s['products_enabled'] && $order instanceof WC_Order && 'yes' === get_option( 'woocommerce_enable_reviews', 'yes' ) ) {
			$seen = array();
			foreach ( $order->get_items() as $item ) {
				if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
					continue;
				}
				$pid = $item->get_product_id(); // Parent ID for variations.
				if ( ! $pid || isset( $seen[ $pid ] ) || ! comments_open( $pid ) || 'publish' !== get_post_status( $pid ) ) {
					continue;
				}
				$seen[ $pid ] = true;
				$products[]   = array(
					'name'  => get_the_title( $pid ),
					'image' => get_the_post_thumbnail_url( $pid, 'woocommerce_thumbnail' ),
					'url'   => $track ? self::click_url( $token, 'p' . $pid ) : get_permalink( $pid ) . '#reviews',
				);
				if ( count( $products ) >= absint( $s['products_max'] ) ) {
					break;
				}
			}
		}

		if ( ! $buttons && ! $products ) {
			if ( 'yes' === $s['products_enabled'] && ! $order ) {
				// Preview with product reviews only and no order to take products from.
				$products[] = array( 'name' => 'Example product', 'image' => '', 'url' => home_url( '/' ) );
			} else {
				return new WP_Error( 'irr_no_links', 'No review platform is enabled, or the order has no reviewable products.' );
			}
		}

		$subject = strtr( $reminder ? $s['reminder_subject'] : $s['subject'], $vars );
		$subject = trim( preg_replace( '/[\r\n\t]+/', ' ', wp_strip_all_tags( $subject ) ) );
		$heading = wp_strip_all_tags( strtr( $reminder ? $s['reminder_heading'] : $s['heading'], $vars ) );
		$message = strtr( $reminder ? $s['reminder_message'] : $s['message'], $vars );
		$unsub   = $token ? self::unsub_url( $token ) : '';
		$colour  = sanitize_hex_color( $s['button_colour'] ) ? $s['button_colour'] : '#00b67a';

		// HTML body.
		$body = '<p>' . esc_html( sprintf( 'Hi %s,', $first ) ) . '</p>' . wpautop( esc_html( $message ) );

		foreach ( $buttons as $i => $b ) {
			$style = ( 0 === $i )
				? 'display:inline-block;padding:14px 28px;background:' . $colour . ';color:#ffffff;text-decoration:none;border-radius:6px;font-weight:bold;'
				: 'display:inline-block;padding:10px 22px;border:2px solid ' . $colour . ';color:' . $colour . ';text-decoration:none;border-radius:6px;font-weight:bold;';
			$body .= '<p style="text-align:center;margin:' . ( 0 === $i ? '28px' : '10px' ) . ' 0;"><a href="' . esc_url( $b['url'] ) . '" style="' . esc_attr( $style ) . '">' . esc_html( $b['label'] ) . '</a></p>';
		}

		if ( $products ) {
			$body .= '<p style="margin-top:28px;"><strong>' . esc_html( $buttons ? 'Or review what you bought:' : 'Review what you bought:' ) . '</strong></p>';
			$body .= '<table cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse;">';
			foreach ( $products as $p ) {
				$body .= '<tr>';
				$body .= '<td style="width:72px;padding:8px 12px 8px 0;vertical-align:middle;">' . ( $p['image'] ? '<img src="' . esc_url( $p['image'] ) . '" width="64" height="64" alt="" style="display:block;border-radius:4px;object-fit:cover;">' : '' ) . '</td>';
				$body .= '<td style="padding:8px 0;vertical-align:middle;">' . esc_html( $p['name'] ) . '</td>';
				$body .= '<td style="padding:8px 0;vertical-align:middle;text-align:right;"><a href="' . esc_url( $p['url'] ) . '" style="color:' . esc_attr( $colour ) . ';font-weight:bold;">Write a review</a></td>';
				$body .= '</tr>';
			}
			$body .= '</table>';
		}

		$body .= '<p style="margin-top:24px;">If anything wasn\'t right, just reply to this email and we\'ll put it right.</p>';
		$body .= '<p>Thanks,<br>' . esc_html( $vars['{site_name}'] ) . '</p>';
		$body .= '<p style="font-size:12px;color:#888888;margin-top:30px;">Don\'t want review requests? <a href="' . esc_url( $unsub ? $unsub : home_url( '/' ) ) . '" style="color:#888888;">Unsubscribe</a></p>';

		$html = self::wrap( $heading, $body );

		// Plain-text alternative.
		$text = sprintf( "Hi %s,\n\n%s\n\n", $first, $message );
		foreach ( $buttons as $b ) {
			$text .= $b['label'] . ': ' . $b['url'] . "\n";
		}
		foreach ( $products as $p ) {
			$text .= 'Review ' . $p['name'] . ': ' . $p['url'] . "\n";
		}
		$text .= "\nThanks,\n" . $vars['{site_name}'] . "\n\nUnsubscribe: " . ( $unsub ? $unsub : home_url( '/' ) ) . "\n";

		return array(
			'subject'   => $subject,
			'html'      => $html,
			'text'      => $text,
			'unsub_url' => $unsub,
		);
	}

	/** Wrap in the store's WooCommerce email design; fall back to a simple layout. */
	private static function wrap( $heading, $body ) {
		if ( function_exists( 'WC' ) && WC() ) {
			$mailer = WC()->mailer();
			if ( $mailer && method_exists( $mailer, 'wrap_message' ) ) {
				$html   = $mailer->wrap_message( $heading, $body );
				$emails = $mailer->get_emails();
				if ( isset( $emails['WC_Email_Customer_Completed_Order'] ) && method_exists( $emails['WC_Email_Customer_Completed_Order'], 'style_inline' ) ) {
					$html = $emails['WC_Email_Customer_Completed_Order']->style_inline( $html );
				}
				return $html;
			}
		}
		return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>'
			. '<body style="margin:0;padding:24px;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;color:#333333;">'
			. '<div style="max-width:600px;margin:0 auto;background:#ffffff;border-radius:8px;padding:32px;">'
			. '<h1 style="font-size:22px;margin:0 0 20px;">' . esc_html( $heading ) . '</h1>' . $body
			. '</div></body></html>';
	}

	public static function click_url( $token, $target ) {
		return add_query_arg( array( 'irr_c' => $token, 'irr_t' => $target ), home_url( '/' ) );
	}

	public static function unsub_url( $token ) {
		return add_query_arg( array( 'irr_u' => $token ), home_url( '/' ) );
	}
}
