<?php
/**
 * Public links: click tracking redirect and unsubscribe page.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_Public {

	public static function init() {
		add_action( 'wp_loaded', array( __CLASS__, 'route' ), 1 );
	}

	public static function route() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification -- public links authenticated by a random 32-character token.
		if ( isset( $_GET['irr_c'] ) ) {
			self::no_cache();
			self::click( sanitize_text_field( wp_unslash( $_GET['irr_c'] ) ), isset( $_GET['irr_t'] ) ? sanitize_key( wp_unslash( $_GET['irr_t'] ) ) : '' );
		} elseif ( isset( $_GET['irr_u'] ) ) {
			self::no_cache();
			self::unsubscribe( sanitize_text_field( wp_unslash( $_GET['irr_u'] ) ) );
		}
		// phpcs:enable
	}

	private static function no_cache() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
	}

	private static function click( $token, $target ) {
		$row = IRR_DB::get_row_by_token( $token );
		$s   = IRR_Settings::all();
		$map = array(
			'tp' => $s['tp_url'],
			'g'  => $s['g_url'],
			'cu' => $s['custom_url'],
		);

		$url      = '';
		$internal = false;
		if ( isset( $map[ $target ] ) ) {
			$url = $map[ $target ];
		} elseif ( preg_match( '/^p(\d+)$/', $target, $m ) && $row ) {
			// Product review link: only for products that are actually in this order.
			$order = function_exists( 'wc_get_order' ) ? wc_get_order( $row->order_id ) : false;
			if ( $order instanceof WC_Order ) {
				foreach ( $order->get_items() as $item ) {
					if ( is_a( $item, 'WC_Order_Item_Product' ) && (int) $item->get_product_id() === (int) $m[1] ) {
						$url      = get_permalink( (int) $m[1] ) . '#reviews';
						$internal = true;
						break;
					}
				}
			}
		}

		if ( $row && $url && empty( $row->clicked_at ) ) {
			IRR_DB::update_row( $row->id, array( 'clicked_at' => IRR_DB::now(), 'clicked_target' => $target ) );
			IRR_DB::log_row( 'clicked', $row, self::target_label( $target ) );
		}

		if ( ! $url ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		if ( $internal ) {
			wp_safe_redirect( $url );
			exit;
		}
		// Only ever redirects to a review link saved in the plugin settings, never to a URL taken from the request.
		wp_redirect( esc_url_raw( $url ), 302, 'IR Review Requests' ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
		exit;
	}

	public static function target_label( $target ) {
		$labels = array(
			'tp' => 'Trustpilot',
			'g'  => 'Google',
			'cu' => IRR_Settings::get( 'custom_label' ),
		);
		if ( isset( $labels[ $target ] ) ) {
			return $labels[ $target ];
		}
		if ( preg_match( '/^p(\d+)$/', (string) $target, $m ) ) {
			return 'Product: ' . get_the_title( (int) $m[1] );
		}
		return (string) $target;
	}

	private static function unsubscribe( $token ) {
		$row = IRR_DB::get_row_by_token( $token );
		if ( ! $row ) {
			wp_die( esc_html__( 'This unsubscribe link is invalid or has expired.', 'ir-review-requests' ), esc_html__( 'Invalid link', 'ir-review-requests' ), array( 'response' => 404 ) );
		}

		$is_post = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];
		if ( $is_post ) {
			// Handles our confirmation button and one-click unsubscribe from Gmail/Yahoo/Apple Mail.
			IRR_DB::add_optout( $row->email, 'Email link' );
			wp_die( esc_html__( "You've been unsubscribed and won't receive any more review requests from us.", 'ir-review-requests' ), esc_html__( 'Unsubscribed', 'ir-review-requests' ), array( 'response' => 200 ) );
		}

		// GET shows a button, so email security scanners that open links can't unsubscribe people by accident.
		$html  = '<h1>' . esc_html__( 'Unsubscribe from review requests', 'ir-review-requests' ) . '</h1>';
		$html .= '<p>' . esc_html__( 'Click the button below and we will stop sending you review request emails.', 'ir-review-requests' ) . '</p>';
		$html .= '<form method="post" action="' . esc_url( IRR_Email::unsub_url( $row->token ) ) . '"><p><button type="submit" class="button">' . esc_html__( 'Unsubscribe', 'ir-review-requests' ) . '</button></p></form>';
		wp_die( $html, esc_html__( 'Unsubscribe', 'ir-review-requests' ), array( 'response' => 200 ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- every part escaped above.
	}
}
