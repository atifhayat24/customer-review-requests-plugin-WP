<?php
/**
 * Email queue: scheduling, background processing, retries.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_Queue {

	const HOOK     = 'irr2_process_queue';
	const GROUP    = 'irr2';
	const INTERVAL = 300; // 5 minutes.

	/** Retry delays after a failed attempt (seconds). */
	private static $backoff = array( 900, 3600, 21600, 86400 );

	public static function init() {
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_status_changed' ), 20, 4 );
		add_action( self::HOOK, array( __CLASS__, 'process' ) );
		add_action( 'init', array( __CLASS__, 'ensure_runner' ), 20 );
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		add_action( 'shutdown', array( __CLASS__, 'backup_runner' ), 9999 );
	}

	/* ---------- Backup runner ---------- */

	/** Earliest pending send time (UTC timestamp), cached in an option so the check costs nothing. */
	public static function refresh_next_due() {
		global $wpdb;
		$t   = IRR_DB::queue_table();
		$min = $wpdb->get_var( "SELECT MIN(send_at) FROM {$t} WHERE status = 'pending'" ); // phpcs:ignore
		update_option( 'irr2_next_due', $min ? (int) strtotime( $min . ' UTC' ) : 0, true );
	}

	/**
	 * Backup for hosts where WP-Cron / Action Scheduler doesn't run reliably:
	 * when something is due and the normal runner hasn't run in the last 2 minutes,
	 * process a few emails at the end of any page load (after the page has been sent where possible).
	 */
	public static function backup_runner() {
		if ( ( defined( 'WP_CLI' ) && WP_CLI ) || wp_doing_cron() || ! IRR_Settings::is_on( 'enabled' ) ) {
			return;
		}
		$next = (int) get_option( 'irr2_next_due', 0 );
		if ( ( ! $next || $next > time() ) && ! self::backfill_active() ) {
			return;
		}
		if ( (int) get_option( 'irr2_last_run' ) > time() - 2 * MINUTE_IN_SECONDS ) {
			return;
		}
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request(); // Visitor gets their page first; sending happens afterwards.
		} elseif ( function_exists( 'litespeed_finish_request' ) ) {
			litespeed_finish_request();
		}
		self::process( 5, 'backup' );
	}

	/* ---------- Background runner ---------- */

	public static function cron_schedules( $schedules ) {
		$schedules['irr2_five_minutes'] = array(
			'interval' => self::INTERVAL,
			'display'  => 'Every 5 minutes (IR Review Requests)',
		);
		return $schedules;
	}

	public static function uses_action_scheduler() {
		return function_exists( 'as_schedule_recurring_action' ) && function_exists( 'as_next_scheduled_action' );
	}

	/** Make sure the queue runner is scheduled (checked at most every 10 minutes). */
	public static function ensure_runner() {
		if ( get_transient( 'irr2_runner_checked' ) ) {
			return;
		}
		set_transient( 'irr2_runner_checked', 1, 10 * MINUTE_IN_SECONDS );

		if ( self::uses_action_scheduler() ) {
			if ( false === as_next_scheduled_action( self::HOOK, array(), self::GROUP ) ) {
				as_schedule_recurring_action( time() + 60, self::INTERVAL, self::HOOK, array(), self::GROUP );
			}
			wp_clear_scheduled_hook( self::HOOK );
		} elseif ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 60, 'irr2_five_minutes', self::HOOK );
		}
	}

	public static function unschedule_runner() {
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::HOOK );
		}
		wp_clear_scheduled_hook( self::HOOK );
		delete_transient( 'irr2_runner_checked' );
	}

	public static function next_run() {
		if ( self::uses_action_scheduler() ) {
			$next = as_next_scheduled_action( self::HOOK, array(), self::GROUP );
			return is_int( $next ) ? $next : ( true === $next ? time() : 0 );
		}
		$next = wp_next_scheduled( self::HOOK );
		return $next ? (int) $next : 0;
	}

	/* ---------- Queueing ---------- */

	public static function on_status_changed( $order_id, $from, $to, $order = null ) {
		if ( ! IRR_Settings::is_on( 'enabled' ) || $to !== IRR_Settings::get( 'trigger_status' ) ) {
			return;
		}
		$order = ( $order instanceof WC_Order ) ? $order : wc_get_order( $order_id );
		if ( $order instanceof WC_Order ) {
			$when = time() + IRR_Settings::seconds( 'delay_value', 'delay_unit' );
			self::add( $order, 'request', $when, 'Order ' . $to );
		}
	}

	public static function has_request( $order_id ) {
		return IRR_DB::count_where( "order_id = %d AND type = 'request' AND status <> 'cancelled'", array( absint( $order_id ) ) ) > 0;
	}

	/**
	 * Add an email to the queue.
	 *
	 * @return int|false Queue ID.
	 */
	public static function add( WC_Order $order, $type, $send_at_ts, $note = '' ) {
		global $wpdb;
		if ( 'request' === $type && self::has_request( $order->get_id() ) ) {
			return false;
		}
		if ( 'reminder' === $type && IRR_DB::count_where( "order_id = %d AND type = 'reminder' AND status IN ('pending','sending')", array( $order->get_id() ) ) > 0 ) {
			return false;
		}
		$email = strtolower( trim( (string) $order->get_billing_email() ) );
		if ( ! is_email( $email ) ) {
			return false;
		}
		$now = IRR_DB::now();
		$ok  = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			IRR_DB::queue_table(),
			array(
				'order_id'   => $order->get_id(),
				'email'      => IRR_DB::cut( $email, 190 ),
				'customer'   => IRR_DB::cut( sanitize_text_field( trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ), 190 ),
				'type'       => ( 'reminder' === $type ) ? 'reminder' : 'request',
				'status'     => 'pending',
				'attempts'   => 0,
				'token'      => wp_generate_password( 32, false, false ),
				'send_at'    => gmdate( 'Y-m-d H:i:s', (int) $send_at_ts ),
				'note'       => IRR_DB::cut( $note, 255 ),
				'created_at' => $now,
				'updated_at' => $now,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s' )
		);
		if ( ! $ok ) {
			return false;
		}
		$id   = (int) $wpdb->insert_id;
		$next = (int) get_option( 'irr2_next_due', 0 );
		if ( ! $next || (int) $send_at_ts < $next ) {
			update_option( 'irr2_next_due', (int) $send_at_ts, true );
		}
		IRR_DB::log( 'queued', array(
			'queue_id' => $id,
			'order_id' => $order->get_id(),
			'email'    => $email,
			'note'     => ucfirst( $type ) . ' due ' . wp_date( 'j M Y, H:i', (int) $send_at_ts ),
		) );
		return $id;
	}

	/* ---------- Processing ---------- */

	private static function lock() {
		if ( add_option( 'irr2_lock', time(), '', 'no' ) ) {
			return true;
		}
		$t = (int) get_option( 'irr2_lock' );
		if ( $t && $t > time() - 4 * MINUTE_IN_SECONDS ) {
			return false;
		}
		update_option( 'irr2_lock', time(), false );
		return true;
	}

	private static function unlock() {
		delete_option( 'irr2_lock' );
	}

	/**
	 * Runs every 5 minutes in the background (and via the backup runner).
	 *
	 * @param int|null $limit  Max emails this run (default: "emails per run" setting).
	 * @param string   $source What triggered the run.
	 */
	public static function process( $limit = null, $source = 'scheduler' ) {
		if ( ! self::lock() ) {
			return;
		}
		global $wpdb;
		$t = IRR_DB::queue_table();

		try {
			update_option( 'irr2_last_run', time(), false );
			update_option( 'irr2_last_run_source', sanitize_key( $source ), false );

			// Recover emails stuck in "sending" (e.g. the server timed out mid-send).
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'pending', updated_at = %s WHERE status = 'sending' AND updated_at < %s", IRR_DB::now(), gmdate( 'Y-m-d H:i:s', time() - 30 * MINUTE_IN_SECONDS ) ) ); // phpcs:ignore

			self::maybe_cleanup();
			self::backfill_step();

			if ( ! IRR_Settings::is_on( 'enabled' ) || ! function_exists( 'wc_get_order' ) ) {
				return; // Paused (or WooCommerce inactive): queued emails wait.
			}

			$limit = $limit ? absint( $limit ) : absint( IRR_Settings::get( 'batch_size' ) );
			$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE status = 'pending' AND send_at <= %s ORDER BY send_at ASC LIMIT %d", IRR_DB::now(), $limit ) ); // phpcs:ignore
			foreach ( (array) $ids as $id ) {
				self::process_one( (int) $id, false );
			}
		} finally {
			self::refresh_next_due();
			self::unlock();
		}
	}

	/** Atomically claim a row so it can never be sent twice. */
	private static function claim( $id ) {
		global $wpdb;
		$t = IRR_DB::queue_table();
		return 1 === (int) $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'sending', updated_at = %s WHERE id = %d AND status = 'pending'", IRR_DB::now(), $id ) ); // phpcs:ignore
	}

	/**
	 * Send one queued email.
	 *
	 * @param bool $manual Sent by an admin (skips the cooldown check).
	 * @return array { ok: bool, message: string }
	 */
	public static function process_one( $id, $manual ) {
		if ( ! self::claim( $id ) ) {
			return array( 'ok' => false, 'message' => 'This email is not waiting to be sent.' );
		}
		$row = IRR_DB::get_row( $id );
		if ( ! $row ) {
			return array( 'ok' => false, 'message' => 'Email not found.' );
		}

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $row->order_id ) : false;
		if ( ! $order instanceof WC_Order ) {
			return self::skip( $row, 'Order no longer exists' );
		}
		if ( in_array( $order->get_status(), array( 'cancelled', 'refunded', 'failed', 'pending', 'on-hold', 'checkout-draft', 'trash' ), true ) ) {
			return self::skip( $row, 'Order status is ' . $order->get_status() );
		}
		if ( IRR_DB::is_opted_out( $row->email ) ) {
			return self::skip( $row, 'Customer has unsubscribed' );
		}
		if ( 'reminder' === $row->type ) {
			if ( ! IRR_Settings::is_on( 'reminder_enabled' ) && ! $manual ) {
				return self::skip( $row, 'Reminders are turned off' );
			}
			if ( self::order_clicked( $row->order_id ) ) {
				return self::skip( $row, 'Customer already clicked a review link' );
			}
			if ( self::left_product_review( $row ) ) {
				return self::skip( $row, 'Customer already left a product review' );
			}
		} elseif ( ! $manual && self::recently_asked( $row ) ) {
			return self::skip( $row, 'Asked within the last ' . absint( IRR_Settings::get( 'cooldown_days' ) ) . ' days' );
		}

		$mail = IRR_Email::build( $row->type, $order, $row->token );
		if ( is_wp_error( $mail ) ) {
			return self::skip( $row, $mail->get_error_message() );
		}

		$result   = IRR_Mailer::send( $row->email, $mail['subject'], $mail['html'], $mail['text'], $mail['unsub_url'] );
		$attempts = (int) $row->attempts + 1;

		if ( $result['ok'] ) {
			IRR_DB::update_row( $row->id, array(
				'status'     => 'sent',
				'attempts'   => $attempts,
				'sent_at'    => IRR_DB::now(),
				'last_error' => '',
				'note'       => $manual ? 'Sent manually' : '',
			) );
			IRR_DB::log_row( 'sent', $row, ( 'reminder' === $row->type ? 'Reminder' : 'Review request' ) . ( $manual ? ' (sent manually)' : '' ) );
			$order->add_order_note( 'reminder' === $row->type ? 'Review reminder email sent.' : 'Review request email sent.' );

			if ( 'request' === $row->type && IRR_Settings::is_on( 'reminder_enabled' ) ) {
				self::add( $order, 'reminder', time() + IRR_Settings::seconds( 'reminder_value', 'reminder_unit' ), 'Reminder' );
			}
			return array( 'ok' => true, 'message' => 'Email sent.' );
		}

		// Failed: retry with increasing delays, then give up.
		$max = absint( IRR_Settings::get( 'max_attempts' ) );
		if ( $attempts < $max ) {
			$delay = self::$backoff[ min( $attempts - 1, count( self::$backoff ) - 1 ) ];
			IRR_DB::update_row( $row->id, array(
				'status'     => 'pending',
				'attempts'   => $attempts,
				'send_at'    => gmdate( 'Y-m-d H:i:s', time() + $delay ),
				'last_error' => $result['error'],
			) );
			IRR_DB::log_row( 'retry', $row, 'Attempt ' . $attempts . ' failed, retrying in ' . human_time_diff( 0, $delay ) . ': ' . $result['error'] );
		} else {
			IRR_DB::update_row( $row->id, array(
				'status'     => 'failed',
				'attempts'   => $attempts,
				'last_error' => $result['error'],
			) );
			IRR_DB::log_row( 'failed', $row, $result['error'] );
			$order->add_order_note( 'Review request email failed after ' . $attempts . ' attempts: ' . $result['error'] );
		}
		return array( 'ok' => false, 'message' => $result['error'] );
	}

	private static function skip( $row, $reason ) {
		IRR_DB::update_row( $row->id, array( 'status' => 'skipped', 'note' => $reason ) );
		IRR_DB::log_row( 'skipped', $row, $reason );
		return array( 'ok' => false, 'message' => 'Skipped: ' . $reason );
	}

	private static function order_clicked( $order_id ) {
		return IRR_DB::count_where( 'order_id = %d AND clicked_at IS NOT NULL', array( absint( $order_id ) ) ) > 0;
	}

	private static function recently_asked( $row ) {
		$days = absint( IRR_Settings::get( 'cooldown_days' ) );
		if ( ! $days ) {
			return false;
		}
		return IRR_DB::count_where(
			"email = %s AND type = 'request' AND status = 'sent' AND sent_at > %s AND id <> %d",
			array( $row->email, gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ), $row->id )
		) > 0;
	}

	private static function left_product_review( $row ) {
		if ( ! IRR_Settings::is_on( 'products_enabled' ) ) {
			return false;
		}
		global $wpdb;
		$t    = IRR_DB::queue_table();
		$sent = $wpdb->get_var( $wpdb->prepare( "SELECT sent_at FROM {$t} WHERE order_id = %d AND type = 'request' AND status = 'sent' LIMIT 1", $row->order_id ) ); // phpcs:ignore
		if ( ! $sent ) {
			return false;
		}
		$count = get_comments( array(
			'author_email' => $row->email,
			'post_type'    => 'product',
			'status'       => 'all',
			'count'        => true,
			'date_query'   => array( array( 'after' => $sent, 'column' => 'comment_date_gmt' ) ),
		) );
		return (int) $count > 0;
	}

	/* ---------- Admin operations ---------- */

	public static function send_now( $id ) {
		$row = IRR_DB::get_row( $id );
		if ( ! $row || ! in_array( $row->status, array( 'pending', 'failed', 'skipped', 'cancelled' ), true ) ) {
			return array( 'ok' => false, 'message' => 'This email cannot be sent now.' );
		}
		IRR_DB::update_row( $row->id, array( 'status' => 'pending', 'attempts' => 0, 'send_at' => IRR_DB::now() ) );
		return self::process_one( (int) $row->id, true );
	}

	public static function retry( $id ) {
		$row = IRR_DB::get_row( $id );
		if ( ! $row || 'failed' !== $row->status ) {
			return false;
		}
		IRR_DB::update_row( $row->id, array( 'status' => 'pending', 'attempts' => 0, 'send_at' => IRR_DB::now() ) );
		IRR_DB::log_row( 'queued', $row, 'Retry requested by ' . wp_get_current_user()->user_login );
		self::refresh_next_due();
		return true;
	}

	public static function retry_all_failed() {
		global $wpdb;
		$t = IRR_DB::queue_table();
		$n = (int) $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'pending', attempts = 0, send_at = %s, updated_at = %s WHERE status = 'failed'", IRR_DB::now(), IRR_DB::now() ) ); // phpcs:ignore
		self::refresh_next_due();
		return $n;
	}

	public static function cancel( $id ) {
		$row = IRR_DB::get_row( $id );
		if ( ! $row || 'pending' !== $row->status ) {
			return false;
		}
		IRR_DB::update_row( $row->id, array( 'status' => 'cancelled', 'note' => 'Cancelled by ' . wp_get_current_user()->user_login ) );
		IRR_DB::log_row( 'cancelled', $row, 'By ' . wp_get_current_user()->user_login );
		return true;
	}

	/* ---------- Previous customers (runs in the background in chunks) ---------- */

	const BACKFILL_OPT  = 'irr2_backfill';
	const BACKFILL_NOTE = 'Previous customer';

	public static function backfill_state() {
		$s = get_option( self::BACKFILL_OPT );
		return is_array( $s ) ? $s : array();
	}

	public static function backfill_active() {
		return (bool) get_option( 'irr2_backfill_active' );
	}

	/**
	 * Start queueing previous customers.
	 *
	 * @param int  $days         Only orders from the last X days (0 = all time).
	 * @param bool $per_customer One email per customer (their most recent order).
	 */
	public static function backfill_start( $days, $per_customer ) {
		update_option( self::BACKFILL_OPT, array(
			'days'         => absint( $days ),
			'per_customer' => $per_customer ? 1 : 0,
			'status'       => IRR_Settings::get( 'trigger_status' ),
			'page'         => 1,
			'scanned'      => 0,
			'added'        => 0,
			'started'      => time(),
			'finished'     => 0,
			'cancelled'    => 0,
		), false );
		update_option( 'irr2_backfill_active', 1, true );
		self::backfill_step(); // First chunk straight away.
	}

	public static function backfill_cancel() {
		$s = self::backfill_state();
		if ( $s ) {
			$s['finished']  = time();
			$s['cancelled'] = 1;
			update_option( self::BACKFILL_OPT, $s, false );
		}
		update_option( 'irr2_backfill_active', 0, true );
	}

	/** Scan the next chunk of past orders (newest first) and queue them. */
	public static function backfill_step( $chunk = 200 ) {
		if ( ! self::backfill_active() || ! function_exists( 'wc_get_orders' ) ) {
			return;
		}
		$s = self::backfill_state();
		if ( ! $s ) {
			update_option( 'irr2_backfill_active', 0, true );
			return;
		}
		$args = array(
			'status'  => array( $s['status'] ),
			'type'    => 'shop_order',
			'limit'   => $chunk,
			'page'    => max( 1, (int) $s['page'] ),
			'orderby' => 'date',
			'order'   => 'DESC',
			'return'  => 'ids',
		);
		if ( $s['days'] ) {
			$args['date_created'] = '>' . ( (int) $s['started'] - (int) $s['days'] * DAY_IN_SECONDS );
		}
		$ids = (array) wc_get_orders( $args );

		foreach ( $ids as $oid ) {
			$s['scanned']++;
			$order = wc_get_order( $oid );
			if ( ! $order instanceof WC_Order ) {
				continue;
			}
			$email = strtolower( trim( (string) $order->get_billing_email() ) );
			if ( ! is_email( $email ) || IRR_DB::is_opted_out( $email ) ) {
				continue;
			}
			// Newest orders come first, so "one per customer" keeps their most recent order.
			if ( $s['per_customer'] && IRR_DB::count_where( "email = %s AND type = 'request' AND status <> 'cancelled'", array( $email ) ) > 0 ) {
				continue;
			}
			if ( self::add( $order, 'request', time(), self::BACKFILL_NOTE ) ) {
				$s['added']++;
			}
		}

		if ( count( $ids ) < $chunk ) {
			$s['finished'] = time();
			update_option( 'irr2_backfill_active', 0, true );
		} else {
			$s['page']++;
		}
		update_option( self::BACKFILL_OPT, $s, false );
	}

	/** Cancel every previous-customer email that hasn't been sent yet. */
	public static function cancel_backfill_emails() {
		global $wpdb;
		self::backfill_cancel();
		$t = IRR_DB::queue_table();
		$n = (int) $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'cancelled', note = %s, updated_at = %s WHERE status = 'pending' AND note = %s", 'Cancelled (previous customers)', IRR_DB::now(), self::BACKFILL_NOTE ) ); // phpcs:ignore
		self::refresh_next_due();
		return $n;
	}

	/** Delete old records once a day. Pending emails are never deleted. */
	private static function maybe_cleanup() {
		$days = absint( IRR_Settings::get( 'log_retention_days' ) );
		if ( ! $days || get_transient( 'irr2_cleanup' ) ) {
			return;
		}
		set_transient( 'irr2_cleanup', 1, DAY_IN_SECONDS );
		global $wpdb;
		$cut = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$q   = IRR_DB::queue_table();
		$e   = IRR_DB::events_table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$e} WHERE created_at < %s", $cut ) ); // phpcs:ignore
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$q} WHERE status IN ('sent','skipped','cancelled','failed') AND updated_at < %s", $cut ) ); // phpcs:ignore
	}
}
