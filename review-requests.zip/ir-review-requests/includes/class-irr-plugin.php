<?php
/**
 * Bootstrap: hooks, activation, upgrades, legacy migration.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_Plugin {

	public static function init() {
		add_action( 'before_woocommerce_init', array( __CLASS__, 'declare_wc_compat' ) );
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_upgrade' ), 5 );
		add_action( 'init', array( __CLASS__, 'load_textdomain' ) );

		IRR_Settings::init();
		IRR_Queue::init();
		IRR_Public::init();

		if ( is_admin() ) {
			IRR_Admin::init();
		}
	}

	public static function declare_wc_compat() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', IRR_FILE, true );
		}
	}

	public static function load_textdomain() {
		load_plugin_textdomain( 'ir-review-requests', false, dirname( plugin_basename( IRR_FILE ) ) . '/languages' );
	}

	public static function activate() {
		IRR_DB::install();
		self::migrate_legacy();
		set_transient( 'irr2_activation_redirect', 1, 60 );
	}

	public static function deactivate() {
		IRR_Queue::unschedule_runner();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'irr2_db_version' ) !== IRR_DB::DB_VERSION ) {
			IRR_DB::install();
			self::migrate_legacy();
		}
		if ( get_option( 'irr2_version' ) !== IRR_VERSION ) {
			update_option( 'irr2_version', IRR_VERSION, true );
			IRR_Queue::refresh_next_due();
			delete_transient( 'irr2_runner_checked' );
		}
	}

	/**
	 * Carry settings and unsubscribes over from the old single-file versions (1.x), once.
	 */
	public static function migrate_legacy() {
		if ( get_option( 'irr2_migrated' ) ) {
			return;
		}
		update_option( 'irr2_migrated', 1, false );

		$old = get_option( 'irr_settings' );
		if ( is_array( $old ) && ! get_option( IRR_Settings::OPTION ) ) {
			$new = IRR_Settings::defaults();
			if ( ! empty( $old['trustpilot_url'] ) ) {
				$new['tp_enabled'] = 'yes';
				$new['tp_url']     = esc_url_raw( $old['trustpilot_url'] );
			}
			if ( ! empty( $old['google_url'] ) ) {
				$new['g_enabled'] = 'yes';
				$new['g_url']     = esc_url_raw( $old['google_url'] );
			}
			foreach ( array( 'subject', 'heading', 'message' ) as $k ) {
				if ( ! empty( $old[ $k ] ) ) {
					$new[ $k ] = sanitize_textarea_field( $old[ $k ] );
				}
			}
			if ( isset( $old['delay_days'] ) ) {
				$new['delay_value'] = absint( $old['delay_days'] );
				$new['delay_unit']  = 'days';
			}
			if ( isset( $old['cooldown_days'] ) ) {
				$new['cooldown_days'] = absint( $old['cooldown_days'] );
			}
			if ( ! empty( $old['button_colour'] ) && sanitize_hex_color( $old['button_colour'] ) ) {
				$new['button_colour'] = $old['button_colour'];
			}
			$new['enabled'] = 'no'; // Always start paused so the new sending settings can be checked first.
			unset( $new['smtp_pass'] );
			add_option( IRR_Settings::OPTION, $new );
		}

		$old_optouts = get_option( 'irr_optouts' );
		if ( is_array( $old_optouts ) ) {
			foreach ( $old_optouts as $val ) {
				if ( is_array( $val ) && ! empty( $val['e'] ) && is_email( $val['e'] ) ) {
					IRR_DB::add_optout( $val['e'], 'Imported from old version' );
				}
			}
		}

		// Remove jobs left behind by the old versions so they can't error or double-send.
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( 'irr_send_review_request' );
		}
	}

	/** True if an old 1.x copy is still active alongside this one. */
	public static function legacy_active() {
		return class_exists( 'IR_Review_Requests' ) || function_exists( 'irr_schedule_request' ) || defined( 'IRR_TRIGGER_STATUS' );
	}
}
