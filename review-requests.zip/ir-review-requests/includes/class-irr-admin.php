<?php
/**
 * Admin screens: Dashboard, Emails, Activity, Unsubscribes, Settings, Tools & health.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_Admin {

	const SLUG     = 'irr-review-requests';
	const PER_PAGE = 50;

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'activation_redirect' ) );
		add_filter( 'option_page_capability_' . IRR_Settings::GROUP, array( __CLASS__, 'cap' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( IRR_FILE ), array( __CLASS__, 'plugin_links' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'global_notices' ) );

		$actions = array( 'send_now', 'retry', 'cancel', 'retry_failed', 'export_emails', 'export_activity', 'unsub_add', 'unsub_remove', 'test', 'preview', 'run_queue', 'backfill', 'backfill_stop', 'backfill_cancel' );
		foreach ( $actions as $a ) {
			add_action( 'admin_post_irr2_' . $a, array( __CLASS__, 'action_' . $a ) );
		}

		add_filter( 'woocommerce_order_actions', array( __CLASS__, 'order_actions' ) );
		add_action( 'woocommerce_order_action_irr2_send_now', array( __CLASS__, 'order_action_send' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_box' ) );
	}

	/* =========================================================
	 * Access
	 * ======================================================= */

	/** Shop managers get in via manage_woocommerce, administrators via manage_options. */
	public static function cap() {
		return current_user_can( 'manage_woocommerce' ) ? 'manage_woocommerce' : 'manage_options';
	}

	public static function can() {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}

	private static function pages() {
		return array(
			self::SLUG         => __( 'Dashboard', 'ir-review-requests' ),
			'irr-emails'       => __( 'Emails', 'ir-review-requests' ),
			'irr-activity'     => __( 'Activity log', 'ir-review-requests' ),
			'irr-unsubscribes' => __( 'Unsubscribes', 'ir-review-requests' ),
			'irr-settings'     => __( 'Settings', 'ir-review-requests' ),
			'irr-tools'        => __( 'Tools & health', 'ir-review-requests' ),
		);
	}

	private static function current_page() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		return array_key_exists( $page, self::pages() ) ? $page : '';
	}

	private static function url( $page, $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) );
	}

	/* =========================================================
	 * Menu, assets, notices
	 * ======================================================= */

	public static function menu() {
		$cap = self::cap();
		add_menu_page( __( 'Review Requests', 'ir-review-requests' ), __( 'Review Requests', 'ir-review-requests' ), $cap, self::SLUG, array( __CLASS__, 'render' ), 'dashicons-star-filled', 56 );
		foreach ( self::pages() as $slug => $label ) {
			add_submenu_page( self::SLUG, $label . ' – ' . __( 'Review Requests', 'ir-review-requests' ), $label, $cap, $slug, array( __CLASS__, 'render' ) );
		}
	}

	public static function plugin_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url( 'irr-settings' ) ) . '">' . esc_html__( 'Settings', 'ir-review-requests' ) . '</a>' );
		return $links;
	}

	public static function assets() {
		if ( ! self::current_page() ) {
			return;
		}
		wp_enqueue_style( 'irr-admin', IRR_URL . 'assets/admin.css', array(), IRR_VERSION );
		wp_enqueue_script( 'irr-admin', IRR_URL . 'assets/admin.js', array(), IRR_VERSION, true );
	}

	public static function activation_redirect() {
		if ( ! get_transient( 'irr2_activation_redirect' ) ) {
			return;
		}
		delete_transient( 'irr2_activation_redirect' );
		if ( wp_doing_ajax() || is_network_admin() || isset( $_GET['activate-multi'] ) || ! self::can() ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		wp_safe_redirect( self::url( self::SLUG, array( 'welcome' => 1 ) ) );
		exit;
	}

	public static function global_notices() {
		if ( ! self::can() ) {
			return;
		}
		if ( IRR_Plugin::legacy_active() ) {
			echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'IR Review Requests:', 'ir-review-requests' ) . '</strong> ' . esc_html__( 'an older version of this plugin is still active. Go to Plugins, deactivate and delete it, otherwise customers could get two emails.', 'ir-review-requests' ) . '</p></div>';
		}
		if ( ! class_exists( 'WooCommerce' ) ) {
			echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'IR Review Requests:', 'ir-review-requests' ) . '</strong> ' . esc_html__( 'WooCommerce is not active, so no review requests can be sent.', 'ir-review-requests' ) . '</p></div>';
		}
	}

	private static function flash( $type, $text ) {
		set_transient( 'irr2_flash_' . get_current_user_id(), array( $type, (string) $text ), 120 );
	}

	private static function show_flash() {
		$key   = 'irr2_flash_' . get_current_user_id();
		$flash = get_transient( $key );
		if ( is_array( $flash ) && 2 === count( $flash ) ) {
			delete_transient( $key );
			$type = in_array( $flash[0], array( 'success', 'error', 'warning', 'info' ), true ) ? $flash[0] : 'info';
			echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( $flash[1] ) . '</p></div>';
		}
	}

	/* =========================================================
	 * Settings registration
	 * ======================================================= */

	public static function register_settings() {
		register_setting( IRR_Settings::GROUP, IRR_Settings::OPTION, array(
			'type'              => 'array',
			'sanitize_callback' => array( 'IRR_Settings', 'sanitize' ),
			'default'           => IRR_Settings::defaults(),
			'show_in_rest'      => false,
		) );
	}

	/* =========================================================
	 * Page router
	 * ======================================================= */

	public static function render() {
		if ( ! self::can() ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'ir-review-requests' ) );
		}
		$page    = self::current_page();
		$page    = $page ? $page : self::SLUG;
		$enabled = IRR_Settings::is_on( 'enabled' );
		$titles  = self::pages();

		echo '<div class="wrap irr-wrap">';
		echo '<h1 class="irr-title">' . esc_html__( 'Review Requests', 'ir-review-requests' ) . ' <span class="irr-pill ' . ( $enabled ? 'irr-pill-on' : 'irr-pill-off' ) . '">' . esc_html( $enabled ? __( 'Sending', 'ir-review-requests' ) : __( 'Paused', 'ir-review-requests' ) ) . '</span></h1>';

		echo '<nav class="nav-tab-wrapper irr-tabs">';
		foreach ( $titles as $slug => $label ) {
			echo '<a class="nav-tab' . ( $slug === $page ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url( $slug ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';

		if ( 'irr-settings' === $page ) {
			settings_errors();
		}
		self::show_flash();

		if ( isset( $_GET['welcome'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success"><p><strong>' . esc_html__( 'Plugin activated.', 'ir-review-requests' ) . '</strong> ' . esc_html__( 'Start in Settings: add your review links, choose how emails are sent, then send yourself a test from Tools & health. Review requests stay paused until you enable them.', 'ir-review-requests' ) . '</p></div>';
		}
		if ( ! $enabled && 'irr-settings' !== $page ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Review requests are paused. Orders are not being queued and queued emails are waiting.', 'ir-review-requests' ) . ' <a href="' . esc_url( self::url( 'irr-settings' ) ) . '">' . esc_html__( 'Go to Settings', 'ir-review-requests' ) . '</a></p></div>';
		}

		echo '<div class="irr-body">';
		switch ( $page ) {
			case 'irr-emails':
				self::page_emails();
				break;
			case 'irr-activity':
				self::page_activity();
				break;
			case 'irr-unsubscribes':
				self::page_unsubscribes();
				break;
			case 'irr-settings':
				self::page_settings();
				break;
			case 'irr-tools':
				self::page_tools();
				break;
			default:
				self::page_dashboard();
		}
		echo '</div></div>';
	}

	/* =========================================================
	 * Dashboard
	 * ======================================================= */

	private static function page_dashboard() {
		global $wpdb;
		$q     = IRR_DB::queue_table();
		$since = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );

		$pending   = IRR_DB::count_where( "status = 'pending'" );
		$overdue   = IRR_DB::count_where( "status = 'pending' AND send_at <= %s", array( gmdate( 'Y-m-d H:i:s', time() - 30 * MINUTE_IN_SECONDS ) ) );
		$sent30    = IRR_DB::count_where( "status = 'sent' AND sent_at >= %s", array( $since ) );
		$failed    = IRR_DB::count_where( "status = 'failed'" );
		$req30     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT order_id) FROM {$q} WHERE type = 'request' AND status = 'sent' AND sent_at >= %s", $since ) ); // phpcs:ignore
		$clicked30 = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT order_id) FROM {$q} WHERE clicked_at >= %s", $since ) ); // phpcs:ignore
		$unsubs    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . IRR_DB::optout_table() ); // phpcs:ignore
		$rate      = $req30 ? round( min( 100, $clicked30 / $req30 * 100 ), 1 ) . '%' : '–';
		$last_run  = (int) get_option( 'irr2_last_run' );

		$cards = array(
			array( __( 'Sent, last 30 days', 'ir-review-requests' ), number_format_i18n( $sent30 ), sprintf( __( '%s customers asked', 'ir-review-requests' ), number_format_i18n( $req30 ) ) ),
			array( __( 'Click rate', 'ir-review-requests' ), $rate, sprintf( __( '%s customers clicked a review link', 'ir-review-requests' ), number_format_i18n( $clicked30 ) ) ),
			array( __( 'Waiting to send', 'ir-review-requests' ), number_format_i18n( $pending ), $overdue ? sprintf( __( '%s overdue', 'ir-review-requests' ), number_format_i18n( $overdue ) ) : __( 'None overdue', 'ir-review-requests' ) ),
			array( __( 'Failed', 'ir-review-requests' ), number_format_i18n( $failed ), $failed ? __( 'Check Emails for the error', 'ir-review-requests' ) : __( 'All good', 'ir-review-requests' ) ),
			array( __( 'Unsubscribed', 'ir-review-requests' ), number_format_i18n( $unsubs ), __( 'Never emailed again', 'ir-review-requests' ) ),
			array( __( 'Queue last ran', 'ir-review-requests' ), $last_run ? sprintf( __( '%s ago', 'ir-review-requests' ), human_time_diff( $last_run ) ) : __( 'Not yet', 'ir-review-requests' ), __( 'Checks every 5 minutes', 'ir-review-requests' ) ),
		);

		echo '<div class="irr-cards">';
		foreach ( $cards as $c ) {
			echo '<div class="irr-card"><div class="irr-card-label">' . esc_html( $c[0] ) . '</div><div class="irr-card-value">' . esc_html( $c[1] ) . '</div><div class="irr-card-sub">' . esc_html( $c[2] ) . '</div></div>';
		}
		echo '</div>';

		$problems = array_filter( self::health_checks(), function ( $c ) {
			return 'error' === $c['status'];
		} );
		if ( $problems ) {
			echo '<div class="notice notice-error inline"><p><strong>' . esc_html( sprintf( _n( '%d problem needs attention:', '%d problems need attention:', count( $problems ), 'ir-review-requests' ), count( $problems ) ) ) . '</strong> ';
			echo esc_html( implode( ' · ', wp_list_pluck( $problems, 'label' ) ) );
			echo ' – <a href="' . esc_url( self::url( 'irr-tools' ) ) . '">' . esc_html__( 'See Tools & health', 'ir-review-requests' ) . '</a></p></div>';
		}

		if ( ! IRR_Queue::backfill_state() ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'Want reviews from customers who ordered before you installed this?', 'ir-review-requests' ) . ' <a href="' . esc_url( self::url( 'irr-tools' ) . '#irr-previous' ) . '">' . esc_html__( 'Send to previous customers', 'ir-review-requests' ) . '</a></p></div>';
		}

		echo '<h2>' . esc_html__( 'Recent activity', 'ir-review-requests' ) . '</h2>';
		self::events_table( self::query_events( '', '', 1, 12 ) );
		echo '<p><a href="' . esc_url( self::url( 'irr-activity' ) ) . '">' . esc_html__( 'View the full activity log', 'ir-review-requests' ) . '</a></p>';
	}

	/* =========================================================
	 * Emails (queue)
	 * ======================================================= */

	private static function statuses() {
		return array(
			'pending'   => __( 'Waiting', 'ir-review-requests' ),
			'sending'   => __( 'Sending', 'ir-review-requests' ),
			'sent'      => __( 'Sent', 'ir-review-requests' ),
			'failed'    => __( 'Failed', 'ir-review-requests' ),
			'skipped'   => __( 'Skipped', 'ir-review-requests' ),
			'cancelled' => __( 'Cancelled', 'ir-review-requests' ),
		);
	}

	private static function email_filters() {
		// phpcs:disable WordPress.Security.NonceVerification
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$type   = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '';
		$search = isset( $_GET['s'] ) ? trim( sanitize_text_field( wp_unslash( $_GET['s'] ) ) ) : '';
		// phpcs:enable
		return array(
			'status' => array_key_exists( $status, self::statuses() ) ? $status : '',
			'type'   => in_array( $type, array( 'request', 'reminder' ), true ) ? $type : '',
			's'      => $search,
		);
	}

	private static function email_where( $f ) {
		global $wpdb;
		$where  = '1=1';
		$params = array();
		if ( $f['status'] ) {
			$where   .= ' AND status = %s';
			$params[] = $f['status'];
		}
		if ( $f['type'] ) {
			$where   .= ' AND type = %s';
			$params[] = $f['type'];
		}
		if ( '' !== $f['s'] ) {
			if ( ctype_digit( $f['s'] ) ) {
				$where   .= ' AND order_id = %d';
				$params[] = (int) $f['s'];
			} else {
				$like     = '%' . $wpdb->esc_like( $f['s'] ) . '%';
				$where   .= ' AND (email LIKE %s OR customer LIKE %s)';
				$params[] = $like;
				$params[] = $like;
			}
		}
		return array( $where, $params );
	}

	private static function query_emails( $f, $page, $per ) {
		global $wpdb;
		$t                      = IRR_DB::queue_table();
		list( $where, $params ) = self::email_where( $f );
		$params[]               = absint( $per );
		$params[]               = absint( ( max( 1, $page ) - 1 ) * $per );
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", $params ) ); // phpcs:ignore
	}

	private static function page_emails() {
		$f     = self::email_filters();
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
		list( $where, $params ) = self::email_where( $f );
		$total  = IRR_DB::count_where( $where, $params );
		$rows   = self::query_emails( $f, $paged, self::PER_PAGE );
		$failed = IRR_DB::count_where( "status = 'failed'" );
		$export = wp_nonce_url( add_query_arg( array_merge( array( 'action' => 'irr2_export_emails' ), $f ), admin_url( 'admin-post.php' ) ), 'irr2_export_emails' );

		echo '<form method="get" class="irr-filters">';
		echo '<input type="hidden" name="page" value="irr-emails">';
		echo '<select name="status"><option value="">' . esc_html__( 'All statuses', 'ir-review-requests' ) . '</option>';
		foreach ( self::statuses() as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $f['status'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <select name="type"><option value="">' . esc_html__( 'All types', 'ir-review-requests' ) . '</option>';
		echo '<option value="request"' . selected( $f['type'], 'request', false ) . '>' . esc_html__( 'Review request', 'ir-review-requests' ) . '</option>';
		echo '<option value="reminder"' . selected( $f['type'], 'reminder', false ) . '>' . esc_html__( 'Reminder', 'ir-review-requests' ) . '</option></select> ';
		echo '<input type="search" name="s" value="' . esc_attr( $f['s'] ) . '" placeholder="' . esc_attr__( 'Email, name or order ID', 'ir-review-requests' ) . '"> ';
		echo '<button class="button">' . esc_html__( 'Filter', 'ir-review-requests' ) . '</button> ';
		echo '<a class="button" href="' . esc_url( $export ) . '">' . esc_html__( 'Export CSV', 'ir-review-requests' ) . '</a> ';
		echo '<span class="irr-count">' . esc_html( sprintf( _n( '%s email', '%s emails', $total, 'ir-review-requests' ), number_format_i18n( $total ) ) ) . '</span>';
		echo '</form>';

		if ( $failed ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="irr-inline-form">';
			echo '<input type="hidden" name="action" value="irr2_retry_failed">';
			wp_nonce_field( 'irr2_retry_failed' );
			echo '<button class="button">' . esc_html( sprintf( __( 'Retry all failed (%s)', 'ir-review-requests' ), number_format_i18n( $failed ) ) ) . '</button></form>';
		}

		echo '<table class="widefat striped irr-table"><thead><tr>';
		foreach ( array( __( 'Order', 'ir-review-requests' ), __( 'Customer', 'ir-review-requests' ), __( 'Type', 'ir-review-requests' ), __( 'Status', 'ir-review-requests' ), __( 'Scheduled / sent', 'ir-review-requests' ), __( 'Clicked', 'ir-review-requests' ), __( 'Details', 'ir-review-requests' ), __( 'Actions', 'ir-review-requests' ) ) as $h ) {
			echo '<th>' . esc_html( $h ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="8">' . esc_html__( 'No emails yet. They appear here as soon as an order reaches the trigger status.', 'ir-review-requests' ) . '</td></tr>';
		}
		$labels = self::statuses();
		foreach ( $rows as $r ) {
			$when = $r->sent_at ? $r->sent_at : $r->send_at;
			echo '<tr>';
			echo '<td>' . self::order_link( $r->order_id ) . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in order_link().
			echo '<td>' . esc_html( $r->customer ) . '<br><span class="irr-muted">' . esc_html( $r->email ) . '</span></td>';
			echo '<td>' . esc_html( 'reminder' === $r->type ? __( 'Reminder', 'ir-review-requests' ) : __( 'Request', 'ir-review-requests' ) ) . '</td>';
			echo '<td><span class="irr-badge irr-badge-' . esc_attr( $r->status ) . '">' . esc_html( isset( $labels[ $r->status ] ) ? $labels[ $r->status ] : $r->status ) . '</span>' . ( (int) $r->attempts > 1 ? '<br><span class="irr-muted">' . esc_html( sprintf( __( '%d attempts', 'ir-review-requests' ), $r->attempts ) ) . '</span>' : '' ) . '</td>';
			$due_note = '';
			if ( 'pending' === $r->status ) {
				$ts       = (int) strtotime( $r->send_at . ' UTC' );
				$due_note = $ts > time() ? sprintf( __( 'in %s', 'ir-review-requests' ), human_time_diff( $ts ) ) : __( 'due – sending within a few minutes', 'ir-review-requests' );
			}
			echo '<td>' . esc_html( get_date_from_gmt( $when, 'j M Y, H:i' ) ) . ( $due_note ? '<br><span class="irr-muted">' . esc_html( $due_note ) . '</span>' : '' ) . '</td>';
			echo '<td>' . ( $r->clicked_at ? esc_html( IRR_Public::target_label( $r->clicked_target ) ) . '<br><span class="irr-muted">' . esc_html( get_date_from_gmt( $r->clicked_at, 'j M, H:i' ) ) . '</span>' : '–' ) . '</td>';
			echo '<td>' . esc_html( $r->note ) . ( $r->last_error ? '<div class="irr-error">' . esc_html( $r->last_error ) . '</div>' : '' ) . '</td>';
			echo '<td class="irr-actions">';
			if ( in_array( $r->status, array( 'pending', 'failed', 'skipped', 'cancelled' ), true ) ) {
				self::row_button( 'send_now', $r->id, __( 'Send now', 'ir-review-requests' ), 'irr-emails' );
			}
			if ( 'failed' === $r->status ) {
				self::row_button( 'retry', $r->id, __( 'Retry', 'ir-review-requests' ), 'irr-emails' );
			}
			if ( 'pending' === $r->status ) {
				self::row_button( 'cancel', $r->id, __( 'Cancel', 'ir-review-requests' ), 'irr-emails', true );
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		self::pagination( $total, $paged );
	}

	private static function row_button( $action, $id, $label, $back, $confirm = false ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $confirm ? ' data-irr-confirm="' . esc_attr__( 'Are you sure?', 'ir-review-requests' ) . '"' : '' ) . '>';
		echo '<input type="hidden" name="action" value="' . esc_attr( 'irr2_' . $action ) . '">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) absint( $id ) ) . '">';
		echo '<input type="hidden" name="back" value="' . esc_attr( $back ) . '">';
		wp_nonce_field( 'irr2_' . $action . '_' . absint( $id ) );
		echo '<button class="button button-small">' . esc_html( $label ) . '</button></form>';
	}

	private static function pagination( $total, $paged ) {
		$pages = (int) ceil( $total / self::PER_PAGE );
		if ( $pages < 2 ) {
			return;
		}
		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo wp_kses_post( paginate_links( array(
			'base'    => add_query_arg( 'paged', '%#%' ),
			'format'  => '',
			'current' => $paged,
			'total'   => $pages,
		) ) );
		echo '</div></div>';
	}

	private static function order_link( $order_id ) {
		$order_id = absint( $order_id );
		if ( ! $order_id ) {
			return '–';
		}
		$o = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		if ( $o instanceof WC_Order ) {
			return '<a href="' . esc_url( $o->get_edit_order_url() ) . '">#' . esc_html( $o->get_order_number() ) . '</a>';
		}
		return '#' . esc_html( (string) $order_id );
	}

	/* =========================================================
	 * Activity log
	 * ======================================================= */

	private static function activity_filters() {
		// phpcs:disable WordPress.Security.NonceVerification
		$event  = isset( $_GET['event'] ) ? sanitize_key( wp_unslash( $_GET['event'] ) ) : '';
		$search = isset( $_GET['s'] ) ? trim( sanitize_text_field( wp_unslash( $_GET['s'] ) ) ) : '';
		// phpcs:enable
		return array(
			'event' => array_key_exists( $event, IRR_DB::event_labels() ) ? $event : '',
			's'     => $search,
		);
	}

	private static function events_where( $event, $search ) {
		global $wpdb;
		$where  = '1=1';
		$params = array();
		if ( $event ) {
			$where   .= ' AND event = %s';
			$params[] = $event;
		}
		if ( '' !== $search ) {
			if ( ctype_digit( $search ) ) {
				$where   .= ' AND order_id = %d';
				$params[] = (int) $search;
			} else {
				$where   .= ' AND email LIKE %s';
				$params[] = '%' . $wpdb->esc_like( $search ) . '%';
			}
		}
		return array( $where, $params );
	}

	private static function query_events( $event, $search, $page, $per ) {
		global $wpdb;
		$t                      = IRR_DB::events_table();
		list( $where, $params ) = self::events_where( $event, $search );
		$params[]               = absint( $per );
		$params[]               = absint( ( max( 1, $page ) - 1 ) * $per );
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", $params ) ); // phpcs:ignore
	}

	private static function count_events( $event, $search ) {
		global $wpdb;
		$t                      = IRR_DB::events_table();
		list( $where, $params ) = self::events_where( $event, $search );
		$sql                    = "SELECT COUNT(*) FROM {$t} WHERE {$where}";
		return (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_var( $sql ) ); // phpcs:ignore
	}

	private static function events_table( array $rows ) {
		$labels = IRR_DB::event_labels();
		echo '<table class="widefat striped irr-table"><thead><tr><th>' . esc_html__( 'Date', 'ir-review-requests' ) . '</th><th>' . esc_html__( 'Event', 'ir-review-requests' ) . '</th><th>' . esc_html__( 'Order', 'ir-review-requests' ) . '</th><th>' . esc_html__( 'Email', 'ir-review-requests' ) . '</th><th>' . esc_html__( 'Details', 'ir-review-requests' ) . '</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="5">' . esc_html__( 'Nothing recorded yet.', 'ir-review-requests' ) . '</td></tr>';
		}
		foreach ( $rows as $r ) {
			$ev = isset( $labels[ $r->event ] ) ? $r->event : 'skipped';
			echo '<tr><td>' . esc_html( get_date_from_gmt( $r->created_at, 'j M Y, H:i' ) ) . '</td>';
			echo '<td><span class="irr-badge irr-badge-' . esc_attr( $ev ) . '">' . esc_html( $labels[ $ev ] ) . '</span></td>';
			echo '<td>' . self::order_link( $r->order_id ) . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in order_link().
			echo '<td>' . esc_html( $r->email ) . '</td><td>' . esc_html( $r->note ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function page_activity() {
		$f      = self::activity_filters();
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$total  = self::count_events( $f['event'], $f['s'] );
		$export = wp_nonce_url( add_query_arg( array_merge( array( 'action' => 'irr2_export_activity' ), $f ), admin_url( 'admin-post.php' ) ), 'irr2_export_activity' );

		echo '<form method="get" class="irr-filters"><input type="hidden" name="page" value="irr-activity">';
		echo '<select name="event"><option value="">' . esc_html__( 'All events', 'ir-review-requests' ) . '</option>';
		foreach ( IRR_DB::event_labels() as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $f['event'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <input type="search" name="s" value="' . esc_attr( $f['s'] ) . '" placeholder="' . esc_attr__( 'Email or order ID', 'ir-review-requests' ) . '"> ';
		echo '<button class="button">' . esc_html__( 'Filter', 'ir-review-requests' ) . '</button> ';
		echo '<a class="button" href="' . esc_url( $export ) . '">' . esc_html__( 'Export CSV', 'ir-review-requests' ) . '</a> ';
		echo '<span class="irr-count">' . esc_html( sprintf( _n( '%s record', '%s records', $total, 'ir-review-requests' ), number_format_i18n( $total ) ) ) . '</span></form>';

		self::events_table( self::query_events( $f['event'], $f['s'], $paged, self::PER_PAGE ) );
		self::pagination( $total, $paged );

		$days = absint( IRR_Settings::get( 'log_retention_days' ) );
		echo '<p class="description">' . esc_html( $days ? sprintf( __( 'Records older than %d days are deleted automatically. Waiting emails are never deleted.', 'ir-review-requests' ), $days ) : __( 'Records are kept forever.', 'ir-review-requests' ) ) . '</p>';
	}

	/* =========================================================
	 * Unsubscribes
	 * ======================================================= */

	private static function page_unsubscribes() {
		global $wpdb;
		$t     = IRR_DB::optout_table();
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ); // phpcs:ignore
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} ORDER BY created_at DESC LIMIT %d OFFSET %d", self::PER_PAGE, ( $paged - 1 ) * self::PER_PAGE ) ); // phpcs:ignore

		echo '<p>' . esc_html__( 'These addresses never receive review requests. Customers are added when they click Unsubscribe; you can also add an address yourself.', 'ir-review-requests' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="irr-filters">';
		echo '<input type="hidden" name="action" value="irr2_unsub_add">';
		wp_nonce_field( 'irr2_unsub_add' );
		echo '<input type="email" name="email" required placeholder="customer@example.com" class="regular-text"> ';
		echo '<button class="button">' . esc_html__( 'Add to unsubscribe list', 'ir-review-requests' ) . '</button></form>';

		echo '<table class="widefat striped irr-table"><thead><tr><th>' . esc_html__( 'Email', 'ir-review-requests' ) . '</th><th>' . esc_html__( 'How', 'ir-review-requests' ) . '</th><th>' . esc_html__( 'Date', 'ir-review-requests' ) . '</th><th></th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="4">' . esc_html__( 'No one has unsubscribed.', 'ir-review-requests' ) . '</td></tr>';
		}
		foreach ( (array) $rows as $r ) {
			echo '<tr><td>' . esc_html( $r->email ) . '</td><td>' . esc_html( $r->source ) . '</td><td>' . esc_html( get_date_from_gmt( $r->created_at, 'j M Y, H:i' ) ) . '</td><td>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-irr-confirm="' . esc_attr__( 'Only re-subscribe someone who has asked you to. Continue?', 'ir-review-requests' ) . '">';
			echo '<input type="hidden" name="action" value="irr2_unsub_remove"><input type="hidden" name="hash" value="' . esc_attr( $r->email_hash ) . '">';
			wp_nonce_field( 'irr2_unsub_remove_' . $r->email_hash );
			echo '<button class="button button-small">' . esc_html__( 'Re-subscribe', 'ir-review-requests' ) . '</button></form></td></tr>';
		}
		echo '</tbody></table>';
		self::pagination( $total, $paged );
	}

	/* =========================================================
	 * Settings
	 * ======================================================= */

	private static function field_checkbox( $key, $label ) {
		$s = IRR_Settings::all();
		echo '<label><input type="checkbox" name="' . esc_attr( IRR_Settings::OPTION . '[' . $key . ']' ) . '" value="yes"' . checked( 'yes', $s[ $key ], false ) . '> ' . esc_html( $label ) . '</label>';
	}

	private static function field_text( $key, $type = 'text', $class = 'regular-text', $attrs = '' ) {
		$s = IRR_Settings::all();
		echo '<input id="irr_' . esc_attr( $key ) . '" type="' . esc_attr( $type ) . '" class="' . esc_attr( $class ) . '" name="' . esc_attr( IRR_Settings::OPTION . '[' . $key . ']' ) . '" value="' . esc_attr( $s[ $key ] ) . '" ' . $attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput -- $attrs are hard-coded strings.
	}

	private static function field_unit( $key ) {
		$s = IRR_Settings::all();
		echo '<select name="' . esc_attr( IRR_Settings::OPTION . '[' . $key . ']' ) . '">';
		foreach ( IRR_Settings::units() as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $s[ $key ], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select>';
	}

	private static function field_textarea( $key ) {
		$s = IRR_Settings::all();
		echo '<textarea id="irr_' . esc_attr( $key ) . '" rows="5" class="large-text" name="' . esc_attr( IRR_Settings::OPTION . '[' . $key . ']' ) . '">' . esc_textarea( $s[ $key ] ) . '</textarea>';
	}

	private static function row( $label, $callback, $desc = '', $class = '' ) {
		echo '<tr' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ) . '><th scope="row">' . esc_html( $label ) . '</th><td>';
		call_user_func( $callback );
		if ( $desc ) {
			echo '<p class="description">' . esc_html( $desc ) . '</p>';
		}
		echo '</td></tr>';
	}

	private static function page_settings() {
		$s    = IRR_Settings::all();
		$name = IRR_Settings::OPTION;

		echo '<p class="irr-jump">';
		foreach ( array( 'general' => __( 'General', 'ir-review-requests' ), 'platforms' => __( 'Review platforms', 'ir-review-requests' ), 'content' => __( 'Email', 'ir-review-requests' ), 'reminder' => __( 'Reminder', 'ir-review-requests' ), 'sending' => __( 'Sending (SMTP)', 'ir-review-requests' ), 'data' => __( 'Data', 'ir-review-requests' ) ) as $id => $l ) {
			echo '<a href="#irr-' . esc_attr( $id ) . '">' . esc_html( $l ) . '</a> ';
		}
		echo '</p>';

		echo '<form method="post" action="options.php" class="irr-settings">';
		settings_fields( IRR_Settings::GROUP );

		/* General */
		echo '<h2 id="irr-general">' . esc_html__( 'General', 'ir-review-requests' ) . '</h2><table class="form-table" role="presentation">';
		self::row( __( 'Review requests', 'ir-review-requests' ), function () {
			self::field_checkbox( 'enabled', __( 'Enabled – queue and send review requests', 'ir-review-requests' ) );
		}, __( 'When off, nothing is queued and anything already queued waits until you turn it back on.', 'ir-review-requests' ) );
		self::row( __( 'Start the countdown when order is', 'ir-review-requests' ), function () use ( $s, $name ) {
			echo '<select name="' . esc_attr( $name . '[trigger_status]' ) . '">';
			foreach ( IRR_Settings::status_choices() as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $s['trigger_status'], $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select>';
		}, __( 'Completed is recommended. Custom statuses such as Delivered appear here if a tracking plugin adds them.', 'ir-review-requests' ) );
		self::row( __( 'Wait before sending', 'ir-review-requests' ), function () {
			self::field_text( 'delay_value', 'number', 'small-text', 'min="0" max="999"' );
			echo ' ';
			self::field_unit( 'delay_unit' );
			echo ' ' . esc_html__( 'after that status', 'ir-review-requests' );
		}, __( 'Use minutes to test in real time (e.g. 2 minutes), then switch back to days. Maximum 90 days.', 'ir-review-requests' ) );
		self::row( __( 'Don\'t ask the same customer again for', 'ir-review-requests' ), function () {
			self::field_text( 'cooldown_days', 'number', 'small-text', 'min="0" max="365"' );
			echo ' ' . esc_html__( 'days (0 = ask every order)', 'ir-review-requests' );
		} );
		echo '</table>';

		/* Platforms */
		echo '<h2 id="irr-platforms">' . esc_html__( 'Review platforms', 'ir-review-requests' ) . '</h2>';
		echo '<p>' . esc_html__( 'Turn on as many as you like. The first one becomes the main button; the others appear as smaller buttons underneath.', 'ir-review-requests' ) . '</p><table class="form-table" role="presentation">';
		self::row( 'Trustpilot', function () {
			self::field_checkbox( 'tp_enabled', __( 'Ask for Trustpilot reviews', 'ir-review-requests' ) );
			echo '<br>';
			self::field_text( 'tp_url', 'url', 'regular-text', 'placeholder="https://uk.trustpilot.com/evaluate/yourdomain.co.uk"' );
		}, __( 'Format: https://uk.trustpilot.com/evaluate/ followed by the domain on your Trustpilot profile.', 'ir-review-requests' ) );
		self::row( 'Google', function () {
			self::field_checkbox( 'g_enabled', __( 'Ask for Google reviews', 'ir-review-requests' ) );
			echo '<br>';
			self::field_text( 'g_url', 'url', 'regular-text', 'placeholder="https://g.page/r/..."' );
		}, __( 'Copy the review link from Google Business Profile → Ask for reviews.', 'ir-review-requests' ) );
		self::row( __( 'Other platform', 'ir-review-requests' ), function () {
			self::field_checkbox( 'custom_enabled', __( 'Ask for reviews on another site', 'ir-review-requests' ) );
			echo '<br>';
			self::field_text( 'custom_label', 'text', 'regular-text', 'placeholder="Facebook"' );
			echo '<br>';
			self::field_text( 'custom_url', 'url', 'regular-text', 'placeholder="https://..."' );
		}, __( 'Name shown on the button (e.g. Facebook, Feefo, Yell) and its review link.', 'ir-review-requests' ) );
		self::row( __( 'Your product reviews', 'ir-review-requests' ), function () {
			self::field_checkbox( 'products_enabled', __( 'List the products they bought with a "Write a review" link', 'ir-review-requests' ) );
			echo '<br>' . esc_html__( 'Show up to', 'ir-review-requests' ) . ' ';
			self::field_text( 'products_max', 'number', 'small-text', 'min="1" max="10"' );
			echo ' ' . esc_html__( 'products', 'ir-review-requests' );
		}, __( 'Uses WooCommerce product reviews on your own site. Reviews must be enabled in WooCommerce → Settings → Products.', 'ir-review-requests' ) );
		self::row( __( 'Click tracking', 'ir-review-requests' ), function () {
			self::field_checkbox( 'track_clicks', __( 'Record which customers click a review link', 'ir-review-requests' ) );
		}, __( 'Links pass through your site and go straight on to the review page. Also used to skip reminders for customers who already clicked.', 'ir-review-requests' ) );
		echo '</table>';

		/* Content */
		echo '<h2 id="irr-content">' . esc_html__( 'Email', 'ir-review-requests' ) . '</h2>';
		echo '<p>' . esc_html__( 'Placeholders: {first_name} {last_name} {order_number} {order_date} {site_name}. The greeting, sign-off and unsubscribe link are added automatically, inside your WooCommerce email design.', 'ir-review-requests' ) . '</p><table class="form-table" role="presentation">';
		self::row( __( 'Subject', 'ir-review-requests' ), function () {
			self::field_text( 'subject', 'text', 'large-text' );
		} );
		self::row( __( 'Heading', 'ir-review-requests' ), function () {
			self::field_text( 'heading', 'text', 'large-text' );
		} );
		self::row( __( 'Message', 'ir-review-requests' ), function () {
			self::field_textarea( 'message' );
		}, __( 'Leave a blank line between paragraphs.', 'ir-review-requests' ) );
		self::row( __( 'Button text', 'ir-review-requests' ), function () {
			self::field_text( 'button_text', 'text', 'regular-text' );
		}, __( '{platform} is replaced with Trustpilot, Google, etc.', 'ir-review-requests' ) );
		self::row( __( 'Button colour', 'ir-review-requests' ), function () {
			self::field_text( 'button_colour', 'color', 'irr-colour' );
		} );
		echo '</table>';

		/* Reminder */
		echo '<h2 id="irr-reminder">' . esc_html__( 'Reminder', 'ir-review-requests' ) . '</h2><table class="form-table" role="presentation">';
		self::row( __( 'Reminder email', 'ir-review-requests' ), function () {
			self::field_checkbox( 'reminder_enabled', __( 'Send one reminder if they haven\'t clicked a review link', 'ir-review-requests' ) );
		}, __( 'Not sent if the customer clicked, left a product review, unsubscribed, or the order was cancelled/refunded.', 'ir-review-requests' ) );
		self::row( __( 'Send reminder after', 'ir-review-requests' ), function () {
			self::field_text( 'reminder_value', 'number', 'small-text', 'min="1" max="999"' );
			echo ' ';
			self::field_unit( 'reminder_unit' );
			echo ' ' . esc_html__( 'after the first email', 'ir-review-requests' );
		} );
		self::row( __( 'Reminder subject', 'ir-review-requests' ), function () {
			self::field_text( 'reminder_subject', 'text', 'large-text' );
		} );
		self::row( __( 'Reminder heading', 'ir-review-requests' ), function () {
			self::field_text( 'reminder_heading', 'text', 'large-text' );
		} );
		self::row( __( 'Reminder message', 'ir-review-requests' ), function () {
			self::field_textarea( 'reminder_message' );
		} );
		echo '</table>';

		/* Sending */
		$has_pass = '' !== (string) $s['smtp_pass'] || defined( 'IRR_SMTP_PASSWORD' );
		echo '<h2 id="irr-sending">' . esc_html__( 'Sending (SMTP)', 'ir-review-requests' ) . '</h2>';
		echo '<p>' . esc_html__( 'These settings only affect review request emails – the rest of your site\'s email is unchanged. Failed sends are retried automatically.', 'ir-review-requests' ) . '</p><table class="form-table" role="presentation">';
		self::row( __( 'Send using', 'ir-review-requests' ), function () use ( $s, $name ) {
			$modes = array(
				'smtp'    => __( 'SMTP server – cPanel/hosting email account (recommended)', 'ir-review-requests' ),
				'php'     => __( 'PHP mail – the server\'s default mailer', 'ir-review-requests' ),
				'wp_mail' => __( 'WordPress default – uses any SMTP plugin you already have', 'ir-review-requests' ),
			);
			foreach ( $modes as $k => $l ) {
				echo '<label class="irr-radio"><input type="radio" name="' . esc_attr( $name . '[mail_mode]' ) . '" value="' . esc_attr( $k ) . '"' . checked( $s['mail_mode'], $k, false ) . ' data-irr-mode> ' . esc_html( $l ) . '</label><br>';
			}
		}, __( 'SMTP is far more reliable than PHP mail and much less likely to land in spam.', 'ir-review-requests' ) );
		self::row( __( 'From email', 'ir-review-requests' ), function () {
			self::field_text( 'from_email', 'email', 'regular-text', 'placeholder="' . esc_attr( IRR_Settings::from_email() ) . '"' );
		}, __( 'Use an address on your own domain (the same account as the SMTP login is best). Blank = WooCommerce "From" address.', 'ir-review-requests' ) );
		self::row( __( 'From name', 'ir-review-requests' ), function () {
			self::field_text( 'from_name', 'text', 'regular-text', 'placeholder="' . esc_attr( IRR_Settings::from_name() ) . '"' );
		} );
		self::row( __( 'Reply-to email', 'ir-review-requests' ), function () {
			self::field_text( 'reply_to', 'email', 'regular-text' );
		}, __( 'Optional. Where customer replies go.', 'ir-review-requests' ) );
		self::row( __( 'SMTP host', 'ir-review-requests' ), function () {
			self::field_text( 'smtp_host', 'text', 'regular-text', 'placeholder="mail.yourdomain.co.uk"' );
		}, __( 'In cPanel: Email Accounts → Connect Devices → "Outgoing Server".', 'ir-review-requests' ), 'irr-smtp' );
		self::row( __( 'Encryption & port', 'ir-review-requests' ), function () use ( $s, $name ) {
			echo '<select name="' . esc_attr( $name . '[smtp_encryption]' ) . '">';
			foreach ( array( 'ssl' => 'SSL', 'tls' => 'TLS (STARTTLS)', 'none' => __( 'None', 'ir-review-requests' ) ) as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $s['smtp_encryption'], $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select> ';
			self::field_text( 'smtp_port', 'number', 'small-text', 'min="1" max="65535"' );
		}, __( 'cPanel usually: SSL with port 465, or TLS with port 587.', 'ir-review-requests' ), 'irr-smtp' );
		self::row( __( 'Authentication', 'ir-review-requests' ), function () {
			self::field_checkbox( 'smtp_auth', __( 'Server requires a username and password (almost always)', 'ir-review-requests' ) );
		}, '', 'irr-smtp' );
		self::row( __( 'Username', 'ir-review-requests' ), function () {
			self::field_text( 'smtp_user', 'text', 'regular-text', 'autocomplete="off" placeholder="reviews@yourdomain.co.uk"' );
		}, __( 'Usually the full email address.', 'ir-review-requests' ), 'irr-smtp' );
		self::row( __( 'Password', 'ir-review-requests' ), function () use ( $has_pass, $name ) {
			if ( defined( 'IRR_SMTP_PASSWORD' ) ) {
				echo '<em>' . esc_html__( 'Set in wp-config.php (IRR_SMTP_PASSWORD).', 'ir-review-requests' ) . '</em>';
				return;
			}
			echo '<input type="password" class="regular-text" name="' . esc_attr( $name . '[smtp_pass_new]' ) . '" value="" autocomplete="new-password" placeholder="' . esc_attr( $has_pass ? __( 'Saved – leave blank to keep', 'ir-review-requests' ) : '' ) . '">';
			if ( $has_pass ) {
				echo '<br><label><input type="checkbox" name="' . esc_attr( $name . '[smtp_pass_clear]' ) . '" value="1"> ' . esc_html__( 'Remove saved password', 'ir-review-requests' ) . '</label>';
			}
		}, __( 'Stored encrypted and never shown again. For extra security you can instead add define( \'IRR_SMTP_PASSWORD\', \'...\' ); to wp-config.php.', 'ir-review-requests' ), 'irr-smtp' );
		self::row( __( 'Emails per run', 'ir-review-requests' ), function () {
			self::field_text( 'batch_size', 'number', 'small-text', 'min="1" max="100"' );
			echo ' ' . esc_html__( 'every 5 minutes', 'ir-review-requests' );
		}, __( 'Keeps you under your host\'s hourly sending limit. 20 every 5 minutes = up to 240 per hour.', 'ir-review-requests' ) );
		self::row( __( 'Attempts before giving up', 'ir-review-requests' ), function () {
			self::field_text( 'max_attempts', 'number', 'small-text', 'min="1" max="10"' );
		}, __( 'Retries after 15 minutes, 1 hour, 6 hours, then daily.', 'ir-review-requests' ) );
		echo '</table>';

		/* Data */
		echo '<h2 id="irr-data">' . esc_html__( 'Data', 'ir-review-requests' ) . '</h2><table class="form-table" role="presentation">';
		self::row( __( 'Keep records for', 'ir-review-requests' ), function () {
			self::field_text( 'log_retention_days', 'number', 'small-text', 'min="0" max="3650"' );
			echo ' ' . esc_html__( 'days (0 = forever)', 'ir-review-requests' );
		} );
		self::row( __( 'On uninstall', 'ir-review-requests' ), function () {
			self::field_checkbox( 'delete_data', __( 'Delete all settings, email records and unsubscribes when the plugin is deleted', 'ir-review-requests' ) );
		}, __( 'Leave off if you might reinstall – the unsubscribe list protects you from emailing people who opted out.', 'ir-review-requests' ) );
		echo '</table>';

		submit_button( __( 'Save settings', 'ir-review-requests' ) );
		echo '</form>';
	}

	/* =========================================================
	 * Tools & health
	 * ======================================================= */

	private static function health_checks() {
		$s      = IRR_Settings::all();
		$checks = array();
		$add    = function ( $label, $status, $msg ) use ( &$checks ) {
			$checks[] = array( 'label' => $label, 'status' => $status, 'message' => $msg );
		};

		$add( 'WooCommerce', class_exists( 'WooCommerce' ) ? 'ok' : 'error', class_exists( 'WooCommerce' ) ? 'Active (version ' . ( defined( 'WC_VERSION' ) ? WC_VERSION : '?' ) . ')' : 'Not active – install and activate WooCommerce.' );
		$add( 'WordPress', 'ok', 'Version ' . get_bloginfo( 'version' ) );
		$add( 'PHP', version_compare( PHP_VERSION, '7.4', '>=' ) ? 'ok' : 'warn', 'Version ' . PHP_VERSION . ( version_compare( PHP_VERSION, '7.4', '<' ) ? ' – ask your host to upgrade to 8.1 or newer.' : '' ) );
		$add( 'Database tables', IRR_DB::tables_exist() ? 'ok' : 'error', IRR_DB::tables_exist() ? 'Present' : 'Missing – deactivate and reactivate the plugin.' );
		$add( 'Old version', IRR_Plugin::legacy_active() ? 'error' : 'ok', IRR_Plugin::legacy_active() ? 'An older copy is still active – delete it from Plugins.' : 'None active' );
		$add( 'Review requests', 'yes' === $s['enabled'] ? 'ok' : 'warn', 'yes' === $s['enabled'] ? 'Enabled' : 'Paused – enable in Settings when ready.' );
		$add( 'Review platforms', IRR_Settings::has_review_target() ? 'ok' : 'error', IRR_Settings::has_review_target() ? implode( ', ', array_merge( wp_list_pluck( IRR_Settings::platforms(), 'label' ), 'yes' === $s['products_enabled'] ? array( 'Product reviews' ) : array() ) ) : 'None turned on – add at least one in Settings.' );

		$mode_labels = array( 'smtp' => 'SMTP server', 'php' => 'PHP mail', 'wp_mail' => 'WordPress default' );
		if ( 'smtp' === $s['mail_mode'] ) {
			if ( ! $s['smtp_host'] ) {
				$add( 'Sending method', 'error', 'SMTP selected but no host set.' );
			} elseif ( 'yes' === $s['smtp_auth'] && '' === IRR_Settings::smtp_password() ) {
				$add( 'Sending method', 'error', 'SMTP password missing or can\'t be decrypted (this happens if wp-config security keys changed) – re-enter it.' );
			} else {
				$add( 'Sending method', 'ok', 'SMTP ' . $s['smtp_host'] . ':' . $s['smtp_port'] . ' (' . strtoupper( $s['smtp_encryption'] ) . ') – send a test below to confirm.' );
			}
		} else {
			$add( 'Sending method', 'php' === $s['mail_mode'] ? 'warn' : 'ok', $mode_labels[ $s['mail_mode'] ] . ( 'php' === $s['mail_mode'] ? ' – works, but SMTP is more reliable and less likely to go to spam.' : '' ) );
		}

		$from        = IRR_Settings::from_email();
		$from_domain = strtolower( (string) substr( strrchr( $from, '@' ), 1 ) );
		$site_domain = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$site_domain = preg_replace( '/^www\./', '', $site_domain );
		$matches     = $from_domain && ( $from_domain === $site_domain || substr( $site_domain, -strlen( '.' . $from_domain ) ) === '.' . $from_domain || substr( $from_domain, -strlen( '.' . $site_domain ) ) === '.' . $site_domain );
		$add( 'From address', $matches ? 'ok' : 'warn', $from . ( $matches ? '' : ' – not on your site\'s domain (' . $site_domain . '). Emails may go to spam.' ) );

		$add( 'Encryption', IRR_Crypto::available() ? 'ok' : 'warn', IRR_Crypto::available() ? 'OpenSSL available – SMTP password stored encrypted.' : 'OpenSSL missing – password stored obfuscated only. Consider defining IRR_SMTP_PASSWORD in wp-config.php.' );

		$last    = (int) get_option( 'irr2_last_run' );
		$next    = IRR_Queue::next_run();
		$overdue = IRR_DB::count_where( "status = 'pending' AND send_at <= %s", array( gmdate( 'Y-m-d H:i:s', time() - 30 * MINUTE_IN_SECONDS ) ) );
		$source  = get_option( 'irr2_last_run_source', 'scheduler' );
		$src_txt = array(
			'scheduler' => IRR_Queue::uses_action_scheduler() ? 'WooCommerce Action Scheduler' : 'WP-Cron',
			'backup'    => 'backup runner (a page visit)',
			'manual'    => 'Run queue now button',
		);
		if ( $overdue && 'yes' === $s['enabled'] && ( ! $last || $last < time() - 30 * MINUTE_IN_SECONDS ) ) {
			$add( 'Background queue', 'error', $overdue . ' emails overdue and the queue hasn\'t run in the last 30 minutes. It runs on WP-Cron, and as a backup whenever someone loads a page on your site. Click "Run queue now" below, and add a server cron job for wp-cron.php (see below) so it runs even with no visitors.' );
		} else {
			$add( 'Background queue', 'ok', 'Last run: ' . ( $last ? human_time_diff( $last ) . ' ago via ' . ( isset( $src_txt[ $source ] ) ? $src_txt[ $source ] : $source ) : 'not yet' ) . '. Next scheduled check: ' . ( $next ? ( $next > time() ? 'in ' . human_time_diff( $next ) : 'due now' ) : 'being scheduled' ) . '. Backup runner: on (sends due emails on page visits if the scheduler is late).' );
		}
		if ( function_exists( 'as_get_scheduled_actions' ) ) {
			$past_due = as_get_scheduled_actions( array(
				'status'       => 'pending',
				'date'         => gmdate( 'Y-m-d H:i:s', time() - 15 * MINUTE_IN_SECONDS ),
				'date_compare' => '<=',
				'per_page'     => 100,
			), 'ids' );
			if ( count( $past_due ) >= 5 ) {
				$add( 'WooCommerce scheduler', 'warn', count( $past_due ) . '+ WooCommerce background jobs are more than 15 minutes late, so WP-Cron is probably not running on this site. Review emails still go out via the backup runner when the site gets visits; for exact timing add the server cron job below.' );
			}
		}
		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
			$add( 'WP-Cron', 'warn', 'DISABLE_WP_CRON is set. Make sure your host runs wp-cron.php on a server cron (every 5 minutes), otherwise emails won\'t send.' );
		}
		return $checks;
	}

	private static function page_tools() {
		$post = esc_url( admin_url( 'admin-post.php' ) );

		echo '<h2>' . esc_html__( 'Health check', 'ir-review-requests' ) . '</h2>';
		echo '<table class="widefat striped irr-table irr-health"><tbody>';
		$icons = array( 'ok' => 'yes-alt', 'warn' => 'warning', 'error' => 'dismiss' );
		foreach ( self::health_checks() as $c ) {
			echo '<tr class="irr-health-' . esc_attr( $c['status'] ) . '"><td style="width:28px;"><span class="dashicons dashicons-' . esc_attr( $icons[ $c['status'] ] ) . '"></span></td><th>' . esc_html( $c['label'] ) . '</th><td>' . esc_html( $c['message'] ) . '</td></tr>';
		}
		echo '</tbody></table>';

		/* Test email */
		echo '<h2>' . esc_html__( 'Send a test email', 'ir-review-requests' ) . '</h2>';
		echo '<p>' . esc_html__( 'Sends the review request email using your current sending settings. Save settings first.', 'ir-review-requests' ) . '</p>';
		echo '<form method="post" action="' . $post . '" class="irr-filters">'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above.
		echo '<input type="hidden" name="action" value="irr2_test">';
		wp_nonce_field( 'irr2_test' );
		echo '<input type="email" name="to" required class="regular-text" value="' . esc_attr( wp_get_current_user()->user_email ) . '"> ';
		echo '<label><input type="checkbox" name="debug" value="1" checked> ' . esc_html__( 'Show SMTP conversation (for troubleshooting)', 'ir-review-requests' ) . '</label> ';
		echo '<button class="button button-primary">' . esc_html__( 'Send test email', 'ir-review-requests' ) . '</button></form>';

		$key    = 'irr2_test_result_' . get_current_user_id();
		$result = get_transient( $key );
		if ( is_array( $result ) ) {
			delete_transient( $key );
			echo '<div class="notice ' . ( $result['ok'] ? 'notice-success' : 'notice-error' ) . ' inline"><p><strong>' . esc_html( $result['ok'] ? __( 'Test email sent. Check the inbox (and spam folder).', 'ir-review-requests' ) : __( 'Test email failed:', 'ir-review-requests' ) ) . '</strong> ' . esc_html( $result['error'] ) . '</p></div>';
			if ( ! empty( $result['debug'] ) ) {
				echo '<details open class="irr-debug"><summary>' . esc_html__( 'SMTP conversation (passwords hidden)', 'ir-review-requests' ) . '</summary><pre>' . esc_html( $result['debug'] ) . '</pre></details>';
			}
		}

		/* Preview */
		echo '<h2>' . esc_html__( 'Preview', 'ir-review-requests' ) . '</h2><p>';
		echo '<a class="button" target="_blank" rel="noopener" href="' . esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'irr2_preview', 'type' => 'request' ), admin_url( 'admin-post.php' ) ), 'irr2_preview' ) ) . '">' . esc_html__( 'Preview review request', 'ir-review-requests' ) . '</a> ';
		echo '<a class="button" target="_blank" rel="noopener" href="' . esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'irr2_preview', 'type' => 'reminder' ), admin_url( 'admin-post.php' ) ), 'irr2_preview' ) ) . '">' . esc_html__( 'Preview reminder', 'ir-review-requests' ) . '</a></p>';
		echo '<p class="description">' . esc_html__( 'Uses your most recent order so you can see real products.', 'ir-review-requests' ) . '</p>';

		/* Queue */
		echo '<h2>' . esc_html__( 'Queue', 'ir-review-requests' ) . '</h2>';
		echo '<form method="post" action="' . $post . '" class="irr-filters">'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above.
		echo '<input type="hidden" name="action" value="irr2_run_queue">';
		wp_nonce_field( 'irr2_run_queue' );
		echo '<button class="button">' . esc_html__( 'Run queue now', 'ir-review-requests' ) . '</button> <span class="description">' . esc_html__( 'Sends anything that is due right now instead of waiting for the next 5-minute run.', 'ir-review-requests' ) . '</span></form>';
		echo '<p class="description" style="margin-top:12px;">' . esc_html__( 'For exact timing on low-traffic sites, add this in cPanel → Cron Jobs → "Once Per Five Minutes":', 'ir-review-requests' ) . '</p>';
		echo '<p><code>' . esc_html( 'wget -q -O - "' . site_url( 'wp-cron.php?doing_wp_cron' ) . '" >/dev/null 2>&1' ) . '</code></p>';

		/* Previous customers */
		self::section_previous_customers( $post );
	}

	private static function section_previous_customers( $post ) {
		$state   = IRR_Queue::backfill_state();
		$active  = IRR_Queue::backfill_active();
		$waiting = IRR_DB::count_where( "status = 'pending' AND note = %s", array( IRR_Queue::BACKFILL_NOTE ) );
		$batch   = max( 1, absint( IRR_Settings::get( 'batch_size' ) ) );

		echo '<h2 id="irr-previous">' . esc_html__( 'Send to previous customers', 'ir-review-requests' ) . '</h2>';
		echo '<p>' . esc_html( sprintf( __( 'Queues a review request for customers whose orders are already "%s". New orders are handled automatically – this is for everyone who ordered before.', 'ir-review-requests' ), self::status_name( IRR_Settings::get( 'trigger_status' ) ) ) ) . '</p>';
		echo '<ul class="irr-list">';
		echo '<li>' . esc_html__( 'Skips unsubscribed customers and orders that have already had a review request.', 'ir-review-requests' ) . '</li>';
		echo '<li>' . esc_html( sprintf( __( 'Sent gradually: %1$d every 5 minutes (about %2$d per hour), set by "Emails per run" in Settings, so your host\'s sending limits aren\'t hit.', 'ir-review-requests' ), $batch, $batch * 12 ) ) . '</li>';
		echo '<li>' . esc_html__( 'Customers from long ago are less likely to review and more likely to mark the email as spam, so the last 12 months usually works best. Trustpilot\'s guidelines also expect reviews to be about recent experiences.', 'ir-review-requests' ) . '</li>';
		echo '</ul>';

		if ( $active && $state ) {
			echo '<div class="notice notice-info inline"><p><strong>' . esc_html__( 'Finding previous customers…', 'ir-review-requests' ) . '</strong> ' . esc_html( sprintf( __( '%1$s orders checked, %2$s queued so far. This continues in the background (about 200 orders every few minutes); refresh to update.', 'ir-review-requests' ), number_format_i18n( $state['scanned'] ), number_format_i18n( $state['added'] ) ) ) . '</p></div>';
		} elseif ( $state && ! empty( $state['finished'] ) ) {
			$range = $state['days'] ? sprintf( __( 'last %d days', 'ir-review-requests' ), $state['days'] ) : __( 'all time', 'ir-review-requests' );
			echo '<div class="notice notice-' . ( empty( $state['cancelled'] ) ? 'success' : 'warning' ) . ' inline"><p>' . esc_html( sprintf( __( 'Last run (%1$s, %2$s): %3$s orders checked, %4$s review requests queued%5$s.', 'ir-review-requests' ), $range, wp_date( 'j M Y, H:i', (int) $state['finished'] ), number_format_i18n( $state['scanned'] ), number_format_i18n( $state['added'] ), empty( $state['cancelled'] ) ? '' : __( ' – stopped early', 'ir-review-requests' ) ) ) . '</p></div>';
		}

		if ( $waiting ) {
			$mins = (int) ceil( $waiting / $batch ) * 5;
			echo '<p>' . esc_html( sprintf( __( '%1$s previous-customer emails waiting to send – roughly %2$s to get through them all.', 'ir-review-requests' ), number_format_i18n( $waiting ), human_time_diff( 0, $mins * MINUTE_IN_SECONDS ) ) ) . ' <a href="' . esc_url( self::url( 'irr-emails', array( 'status' => 'pending' ) ) ) . '">' . esc_html__( 'View them', 'ir-review-requests' ) . '</a></p>';
		}
		if ( ! IRR_Settings::is_on( 'enabled' ) ) {
			echo '<p><em>' . esc_html__( 'Review requests are paused, so queued emails will wait until you enable them in Settings.', 'ir-review-requests' ) . '</em></p>';
		}

		if ( ! $active ) {
			echo '<form method="post" action="' . $post . '" class="irr-filters" data-irr-confirm="' . esc_attr__( 'Queue review requests for these previous customers? They will start sending gradually straight away (if review requests are enabled).', 'ir-review-requests' ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped by caller.
			echo '<input type="hidden" name="action" value="irr2_backfill">';
			wp_nonce_field( 'irr2_backfill' );
			echo '<label>' . esc_html__( 'Orders from', 'ir-review-requests' ) . ' <select name="days">';
			$ranges = array(
				30  => __( 'the last 30 days', 'ir-review-requests' ),
				90  => __( 'the last 3 months', 'ir-review-requests' ),
				180 => __( 'the last 6 months', 'ir-review-requests' ),
				365 => __( 'the last 12 months (recommended)', 'ir-review-requests' ),
				730 => __( 'the last 2 years', 'ir-review-requests' ),
				0   => __( 'all time – every previous customer', 'ir-review-requests' ),
			);
			foreach ( $ranges as $d => $l ) {
				echo '<option value="' . esc_attr( (string) $d ) . '"' . selected( 365, $d, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select></label> ';
			echo '<label><input type="checkbox" name="per_customer" value="1" checked> ' . esc_html__( 'One email per customer (their most recent order)', 'ir-review-requests' ) . '</label> ';
			echo '<button class="button button-primary">' . esc_html__( 'Queue previous customers', 'ir-review-requests' ) . '</button></form>';
		} else {
			echo '<form method="post" action="' . $post . '" class="irr-inline-form">'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped by caller.
			echo '<input type="hidden" name="action" value="irr2_backfill_stop">';
			wp_nonce_field( 'irr2_backfill_stop' );
			echo '<button class="button">' . esc_html__( 'Stop finding more', 'ir-review-requests' ) . '</button></form>';
		}

		if ( $waiting ) {
			echo '<form method="post" action="' . $post . '" class="irr-inline-form" data-irr-confirm="' . esc_attr__( 'Cancel all previous-customer emails that have not been sent yet?', 'ir-review-requests' ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped by caller.
			echo '<input type="hidden" name="action" value="irr2_backfill_cancel">';
			wp_nonce_field( 'irr2_backfill_cancel' );
			echo '<button class="button">' . esc_html__( 'Cancel waiting previous-customer emails', 'ir-review-requests' ) . '</button></form>';
		}
	}

	/* =========================================================
	 * Admin-post handlers (capability + nonce on every one)
	 * ======================================================= */

	private static function guard( $nonce_action ) {
		if ( ! self::can() ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ir-review-requests' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce_action );
	}

	private static function back( $page ) {
		$page = array_key_exists( $page, self::pages() ) ? $page : self::SLUG;
		$ref  = wp_get_referer();
		// Return to the same filtered view if we came from one of our pages.
		if ( $ref && false !== strpos( $ref, 'page=' . $page ) ) {
			wp_safe_redirect( remove_query_arg( array( 'welcome' ), $ref ) );
		} else {
			wp_safe_redirect( self::url( $page ) );
		}
		exit;
	}

	private static function post_id() {
		return isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- nonce checked in guard().
	}

	private static function post_back() {
		return isset( $_POST['back'] ) ? sanitize_key( wp_unslash( $_POST['back'] ) ) : 'irr-emails'; // phpcs:ignore WordPress.Security.NonceVerification -- nonce checked in guard().
	}

	public static function action_send_now() {
		$id = self::post_id();
		self::guard( 'irr2_send_now_' . $id );
		$r = IRR_Queue::send_now( $id );
		self::flash( $r['ok'] ? 'success' : 'error', $r['message'] );
		self::back( self::post_back() );
	}

	public static function action_retry() {
		$id = self::post_id();
		self::guard( 'irr2_retry_' . $id );
		$ok = IRR_Queue::retry( $id );
		self::flash( $ok ? 'success' : 'error', $ok ? __( 'Queued to retry on the next run (within 5 minutes).', 'ir-review-requests' ) : __( 'This email cannot be retried.', 'ir-review-requests' ) );
		self::back( self::post_back() );
	}

	public static function action_cancel() {
		$id = self::post_id();
		self::guard( 'irr2_cancel_' . $id );
		$ok = IRR_Queue::cancel( $id );
		self::flash( $ok ? 'success' : 'error', $ok ? __( 'Email cancelled.', 'ir-review-requests' ) : __( 'This email cannot be cancelled.', 'ir-review-requests' ) );
		self::back( self::post_back() );
	}

	public static function action_retry_failed() {
		self::guard( 'irr2_retry_failed' );
		$n = IRR_Queue::retry_all_failed();
		self::flash( 'success', sprintf( _n( '%d email queued to retry.', '%d emails queued to retry.', $n, 'ir-review-requests' ), $n ) );
		self::back( 'irr-emails' );
	}

	public static function action_unsub_add() {
		self::guard( 'irr2_unsub_add' );
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- checked in guard().
		$ok    = is_email( $email ) && IRR_DB::add_optout( $email, 'Added by ' . wp_get_current_user()->user_login );
		self::flash( $ok ? 'success' : 'error', $ok ? __( 'Address added to the unsubscribe list.', 'ir-review-requests' ) : __( 'Invalid address, or it is already on the list.', 'ir-review-requests' ) );
		self::back( 'irr-unsubscribes' );
	}

	public static function action_unsub_remove() {
		$hash = isset( $_POST['hash'] ) ? sanitize_key( wp_unslash( $_POST['hash'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- checked in guard().
		self::guard( 'irr2_unsub_remove_' . $hash );
		IRR_DB::remove_optout( $hash );
		self::flash( 'success', __( 'Customer re-subscribed.', 'ir-review-requests' ) );
		self::back( 'irr-unsubscribes' );
	}

	public static function action_test() {
		self::guard( 'irr2_test' );
		// phpcs:disable WordPress.Security.NonceVerification -- checked in guard().
		$to    = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';
		$debug = ! empty( $_POST['debug'] );
		// phpcs:enable
		$result = array( 'ok' => false, 'error' => '', 'debug' => '' );
		if ( ! is_email( $to ) ) {
			$result['error'] = __( 'Enter a valid email address.', 'ir-review-requests' );
		} else {
			$mail = IRR_Email::build( 'request', self::latest_order(), '' );
			if ( is_wp_error( $mail ) ) {
				$mail = self::fallback_test_mail();
			}
			$result = IRR_Mailer::send( $to, '[TEST] ' . $mail['subject'], $mail['html'], $mail['text'], '', $debug );
			IRR_DB::log( 'test', array( 'email' => $to, 'note' => $result['ok'] ? 'Test sent via ' . IRR_Settings::get( 'mail_mode' ) : 'Test failed: ' . $result['error'] ) );
		}
		set_transient( 'irr2_test_result_' . get_current_user_id(), $result, 300 );
		self::back( 'irr-tools' );
	}

	/** Used when no review platform is configured yet, so SMTP can still be tested. */
	private static function fallback_test_mail() {
		$html = '<p>This is a test email from IR Review Requests on ' . esc_html( get_bloginfo( 'name' ) ) . '.</p><p>Your sending settings work. Turn on a review platform in Settings to see the real email.</p>';
		return array( 'subject' => 'Sending test', 'html' => $html, 'text' => wp_strip_all_tags( $html ) );
	}

	private static function latest_order() {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return null;
		}
		$orders = wc_get_orders( array( 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC', 'type' => 'shop_order' ) );
		return ( $orders && $orders[0] instanceof WC_Order ) ? $orders[0] : null;
	}

	public static function action_preview() {
		self::guard( 'irr2_preview' );
		$type = ( isset( $_GET['type'] ) && 'reminder' === $_GET['type'] ) ? 'reminder' : 'request'; // phpcs:ignore WordPress.Security.NonceVerification -- checked in guard().
		$mail = IRR_Email::build( $type, self::latest_order(), '' );
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		if ( is_wp_error( $mail ) ) {
			echo '<p style="font:15px sans-serif;padding:20px;">' . esc_html__( 'Nothing to preview yet: turn on at least one review platform in Settings.', 'ir-review-requests' ) . '</p>';
			exit;
		}
		echo '<div style="font:14px sans-serif;background:#fff8e1;padding:10px 16px;border-bottom:1px solid #e6c65c;">' . esc_html__( 'Preview – subject:', 'ir-review-requests' ) . ' <strong>' . esc_html( $mail['subject'] ) . '</strong></div>';
		echo $mail['html']; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts in IRR_Email::build().
		exit;
	}

	public static function action_run_queue() {
		self::guard( 'irr2_run_queue' );
		IRR_Queue::process( null, 'manual' );
		self::flash( 'success', IRR_Settings::is_on( 'enabled' ) ? __( 'Queue processed. See Emails for results.', 'ir-review-requests' ) : __( 'Queue checked, but review requests are paused so nothing was sent.', 'ir-review-requests' ) );
		self::back( 'irr-tools' );
	}

	public static function action_backfill() {
		self::guard( 'irr2_backfill' );
		// phpcs:disable WordPress.Security.NonceVerification -- checked in guard().
		$days = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 365;
		$days = in_array( $days, array( 0, 30, 90, 180, 365, 730 ), true ) ? $days : 365;
		$per  = ! empty( $_POST['per_customer'] );
		// phpcs:enable
		IRR_Queue::backfill_start( $days, $per );
		$state = IRR_Queue::backfill_state();
		self::flash( 'success', IRR_Queue::backfill_active()
			? sprintf( __( 'Started. %s queued from the first batch; the rest are being found in the background.', 'ir-review-requests' ), number_format_i18n( $state['added'] ) )
			: sprintf( __( 'Done: %1$s orders checked, %2$s review requests queued.', 'ir-review-requests' ), number_format_i18n( $state['scanned'] ), number_format_i18n( $state['added'] ) ) );
		wp_safe_redirect( self::url( 'irr-tools' ) . '#irr-previous' );
		exit;
	}

	public static function action_backfill_stop() {
		self::guard( 'irr2_backfill_stop' );
		IRR_Queue::backfill_cancel();
		self::flash( 'success', __( 'Stopped. Emails already queued will still send.', 'ir-review-requests' ) );
		wp_safe_redirect( self::url( 'irr-tools' ) . '#irr-previous' );
		exit;
	}

	public static function action_backfill_cancel() {
		self::guard( 'irr2_backfill_cancel' );
		$n = IRR_Queue::cancel_backfill_emails();
		self::flash( 'success', sprintf( _n( '%d waiting email cancelled.', '%d waiting emails cancelled.', $n, 'ir-review-requests' ), $n ) );
		wp_safe_redirect( self::url( 'irr-tools' ) . '#irr-previous' );
		exit;
	}

	/* ---------- CSV export ---------- */

	private static function csv_cell( $v ) {
		$v = (string) $v;
		if ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			$v = "'" . $v; // Stop spreadsheet formula injection.
		}
		return $v;
	}

	private static function csv_start( $name ) {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . $name . '-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- UTF-8 BOM for Excel.
		return $out;
	}

	public static function action_export_emails() {
		self::guard( 'irr2_export_emails' );
		$rows = self::query_emails( self::email_filters(), 1, 50000 );
		$out  = self::csv_start( 'review-request-emails' );
		fputcsv( $out, array( 'Queue ID', 'Order ID', 'Customer', 'Email', 'Type', 'Status', 'Attempts', 'Scheduled (UTC)', 'Sent (UTC)', 'Clicked (UTC)', 'Clicked', 'Note', 'Last error' ) );
		foreach ( $rows as $r ) {
			fputcsv( $out, array_map( array( __CLASS__, 'csv_cell' ), array( $r->id, $r->order_id, $r->customer, $r->email, $r->type, $r->status, $r->attempts, $r->send_at, $r->sent_at, $r->clicked_at, $r->clicked_target ? IRR_Public::target_label( $r->clicked_target ) : '', $r->note, $r->last_error ) ) );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	public static function action_export_activity() {
		self::guard( 'irr2_export_activity' );
		$f      = self::activity_filters();
		$rows   = self::query_events( $f['event'], $f['s'], 1, 50000 );
		$labels = IRR_DB::event_labels();
		$out    = self::csv_start( 'review-request-activity' );
		fputcsv( $out, array( 'Date (UTC)', 'Event', 'Order ID', 'Email', 'Details' ) );
		foreach ( $rows as $r ) {
			fputcsv( $out, array_map( array( __CLASS__, 'csv_cell' ), array( $r->created_at, isset( $labels[ $r->event ] ) ? $labels[ $r->event ] : $r->event, $r->order_id, $r->email, $r->note ) ) );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	/* =========================================================
	 * Order screen integration
	 * ======================================================= */

	public static function order_actions( $actions ) {
		if ( is_array( $actions ) && self::can() ) {
			$actions['irr2_send_now'] = __( 'Send review request email now', 'ir-review-requests' );
		}
		return $actions;
	}

	public static function order_action_send( $order ) {
		if ( ! $order instanceof WC_Order || ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}
		global $wpdb;
		$t  = IRR_DB::queue_table();
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE order_id = %d AND type = 'request' ORDER BY id DESC LIMIT 1", $order->get_id() ) ); // phpcs:ignore
		if ( $id ) {
			$row = IRR_DB::get_row( $id );
			if ( $row && 'sent' === $row->status ) {
				// Already sent once: queue a fresh manual copy.
				IRR_DB::update_row( $id, array( 'status' => 'pending', 'attempts' => 0, 'send_at' => IRR_DB::now() ) );
			}
			$r = IRR_Queue::send_now( $id );
		} else {
			$new = IRR_Queue::add( $order, 'request', time(), 'Sent manually from order screen' );
			$r   = $new ? IRR_Queue::process_one( $new, true ) : array( 'ok' => false, 'message' => 'Could not queue (check the billing email).' );
		}
		if ( ! $r['ok'] ) {
			$order->add_order_note( 'Review request not sent: ' . $r['message'] );
		}
	}

	public static function meta_box() {
		$screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
		add_meta_box( 'irr2-review-request', __( 'Review request', 'ir-review-requests' ), array( __CLASS__, 'render_meta_box' ), $screen, 'side', 'low' );
	}

	public static function render_meta_box( $post_or_order ) {
		global $wpdb;
		$order_id = 0;
		if ( $post_or_order instanceof WC_Order ) {
			$order_id = $post_or_order->get_id();
		} elseif ( $post_or_order instanceof WP_Post ) {
			$order_id = $post_or_order->ID;
		}
		$t    = IRR_DB::queue_table();
		$rows = $order_id ? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE order_id = %d ORDER BY id ASC", $order_id ) ) : array(); // phpcs:ignore
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'No review request yet.', 'ir-review-requests' ) . '</p>';
		}
		$labels = self::statuses();
		foreach ( (array) $rows as $r ) {
			$when = $r->sent_at ? $r->sent_at : $r->send_at;
			echo '<p><strong>' . esc_html( 'reminder' === $r->type ? __( 'Reminder', 'ir-review-requests' ) : __( 'Request', 'ir-review-requests' ) ) . ':</strong> ';
			echo '<span class="irr-badge irr-badge-' . esc_attr( $r->status ) . '">' . esc_html( isset( $labels[ $r->status ] ) ? $labels[ $r->status ] : $r->status ) . '</span><br>';
			echo esc_html( get_date_from_gmt( $when, 'j M Y, H:i' ) );
			if ( $r->clicked_at ) {
				echo '<br>' . esc_html( sprintf( __( 'Clicked: %s', 'ir-review-requests' ), IRR_Public::target_label( $r->clicked_target ) ) );
			}
			if ( $r->note ) {
				echo '<br><em>' . esc_html( $r->note ) . '</em>';
			}
			echo '</p>';
		}
		echo '<p><a href="' . esc_url( self::url( 'irr-emails', array( 's' => $order_id ) ) ) . '">' . esc_html__( 'View in Review Requests', 'ir-review-requests' ) . '</a></p>';
	}

	/** Order status name without fatals if WooCommerce is missing. */
	private static function status_name( $status ) {
		return function_exists( 'wc_get_order_status_name' ) ? wc_get_order_status_name( $status ) : ucfirst( (string) $status );
	}
}
