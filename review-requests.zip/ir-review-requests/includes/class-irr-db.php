<?php
/**
 * Database tables: email queue, activity events, unsubscribes.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_DB {

	const DB_VERSION = '2';

	public static function queue_table() {
		global $wpdb;
		return $wpdb->prefix . 'irr2_queue';
	}

	public static function events_table() {
		global $wpdb;
		return $wpdb->prefix . 'irr2_events';
	}

	public static function optout_table() {
		global $wpdb;
		return $wpdb->prefix . 'irr2_optouts';
	}

	public static function now() {
		return current_time( 'mysql', true );
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		dbDelta( 'CREATE TABLE ' . self::queue_table() . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			email varchar(190) NOT NULL DEFAULT '',
			customer varchar(190) NOT NULL DEFAULT '',
			type varchar(20) NOT NULL DEFAULT 'request',
			status varchar(20) NOT NULL DEFAULT 'pending',
			attempts smallint(5) unsigned NOT NULL DEFAULT 0,
			token char(32) NOT NULL DEFAULT '',
			send_at datetime NOT NULL,
			sent_at datetime NULL DEFAULT NULL,
			clicked_at datetime NULL DEFAULT NULL,
			clicked_target varchar(40) NOT NULL DEFAULT '',
			last_error text NULL,
			note varchar(255) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY status_send (status,send_at),
			KEY order_id (order_id),
			KEY email (email),
			KEY token (token)
		) $charset;" );

		dbDelta( 'CREATE TABLE ' . self::events_table() . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			queue_id bigint(20) unsigned NOT NULL DEFAULT 0,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			email varchar(190) NOT NULL DEFAULT '',
			event varchar(20) NOT NULL DEFAULT '',
			note varchar(255) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY order_id (order_id)
		) $charset;" );

		dbDelta( 'CREATE TABLE ' . self::optout_table() . " (
			email_hash char(32) NOT NULL,
			email varchar(190) NOT NULL DEFAULT '',
			source varchar(100) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (email_hash)
		) $charset;" );

		update_option( 'irr2_db_version', self::DB_VERSION, true );
	}

	public static function tables_exist() {
		global $wpdb;
		foreach ( array( self::queue_table(), self::events_table(), self::optout_table() ) as $t ) {
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) !== $t ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				return false;
			}
		}
		return true;
	}

	public static function cut( $value, $len ) {
		$value = (string) $value;
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $len ) : substr( $value, 0, $len );
	}

	/* ---------- Events ---------- */

	public static function event_labels() {
		return array(
			'queued'       => __( 'Queued', 'ir-review-requests' ),
			'sent'         => __( 'Sent', 'ir-review-requests' ),
			'retry'        => __( 'Retrying', 'ir-review-requests' ),
			'failed'       => __( 'Failed', 'ir-review-requests' ),
			'skipped'      => __( 'Skipped', 'ir-review-requests' ),
			'clicked'      => __( 'Clicked', 'ir-review-requests' ),
			'cancelled'    => __( 'Cancelled', 'ir-review-requests' ),
			'unsubscribed' => __( 'Unsubscribed', 'ir-review-requests' ),
			'resubscribed' => __( 'Re-subscribed', 'ir-review-requests' ),
			'test'         => __( 'Test email', 'ir-review-requests' ),
		);
	}

	public static function log( $event, $args = array() ) {
		global $wpdb;
		$args = wp_parse_args( $args, array( 'queue_id' => 0, 'order_id' => 0, 'email' => '', 'note' => '' ) );
		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::events_table(),
			array(
				'queue_id'   => absint( $args['queue_id'] ),
				'order_id'   => absint( $args['order_id'] ),
				'email'      => self::cut( sanitize_email( $args['email'] ), 190 ),
				'event'      => array_key_exists( $event, self::event_labels() ) ? $event : 'skipped',
				'note'       => self::cut( sanitize_text_field( $args['note'] ), 255 ),
				'created_at' => self::now(),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s' )
		);
	}

	public static function log_row( $event, $row, $note = '' ) {
		self::log( $event, array(
			'queue_id' => isset( $row->id ) ? $row->id : 0,
			'order_id' => isset( $row->order_id ) ? $row->order_id : 0,
			'email'    => isset( $row->email ) ? $row->email : '',
			'note'     => $note,
		) );
	}

	/* ---------- Unsubscribes ---------- */

	public static function hash_email( $email ) {
		return md5( strtolower( trim( (string) $email ) ) );
	}

	public static function is_opted_out( $email ) {
		global $wpdb;
		$t = self::optout_table();
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$t} WHERE email_hash = %s LIMIT 1", self::hash_email( $email ) ) ); // phpcs:ignore
	}

	public static function add_optout( $email, $source ) {
		global $wpdb;
		$email = strtolower( trim( sanitize_email( $email ) ) );
		if ( ! is_email( $email ) || self::is_opted_out( $email ) ) {
			return false;
		}
		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::optout_table(),
			array(
				'email_hash' => self::hash_email( $email ),
				'email'      => self::cut( $email, 190 ),
				'source'     => self::cut( sanitize_text_field( $source ), 100 ),
				'created_at' => self::now(),
			),
			array( '%s', '%s', '%s', '%s' )
		);
		// Cancel anything still waiting for this address.
		$q = self::queue_table();
		$wpdb->query( $wpdb->prepare( "UPDATE {$q} SET status = 'cancelled', note = %s, updated_at = %s WHERE email = %s AND status = 'pending'", 'Unsubscribed', self::now(), $email ) ); // phpcs:ignore
		self::log( 'unsubscribed', array( 'email' => $email, 'note' => $source ) );
		return true;
	}

	public static function remove_optout( $hash ) {
		global $wpdb;
		if ( ! preg_match( '/^[a-f0-9]{32}$/', (string) $hash ) ) {
			return false;
		}
		$t     = self::optout_table();
		$email = $wpdb->get_var( $wpdb->prepare( "SELECT email FROM {$t} WHERE email_hash = %s", $hash ) ); // phpcs:ignore
		$wpdb->delete( $t, array( 'email_hash' => $hash ), array( '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $email ) {
			self::log( 'resubscribed', array( 'email' => $email, 'note' => 'By ' . wp_get_current_user()->user_login ) );
		}
		return true;
	}

	/* ---------- Queue helpers ---------- */

	public static function get_row( $id ) {
		global $wpdb;
		$t = self::queue_table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ) ); // phpcs:ignore
	}

	public static function get_row_by_token( $token ) {
		global $wpdb;
		if ( ! preg_match( '/^[A-Za-z0-9]{32}$/', (string) $token ) ) {
			return null;
		}
		$t = self::queue_table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE token = %s LIMIT 1", $token ) ); // phpcs:ignore
	}

	public static function update_row( $id, array $data ) {
		global $wpdb;
		$data['updated_at'] = self::now();
		if ( isset( $data['last_error'] ) ) {
			$data['last_error'] = self::cut( $data['last_error'], 1000 );
		}
		if ( isset( $data['note'] ) ) {
			$data['note'] = self::cut( $data['note'], 255 );
		}
		return $wpdb->update( self::queue_table(), $data, array( 'id' => absint( $id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	public static function count_where( $where_sql, $params = array() ) {
		global $wpdb;
		$t   = self::queue_table();
		$sql = "SELECT COUNT(*) FROM {$t} WHERE {$where_sql}";
		return (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_var( $sql ) ); // phpcs:ignore
	}
}
