<?php
/**
 * Encrypts the SMTP password at rest (AES-256-CBC + HMAC), keyed from wp-config salts.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_Crypto {

	private static function base_key() {
		$key  = defined( 'LOGGED_IN_KEY' ) ? LOGGED_IN_KEY : '';
		$salt = defined( 'LOGGED_IN_SALT' ) ? LOGGED_IN_SALT : '';
		return $key . '|' . $salt . '|irr-smtp';
	}

	private static function enc_key() {
		return hash( 'sha256', 'enc|' . self::base_key(), true );
	}

	private static function mac_key() {
		return hash( 'sha256', 'mac|' . self::base_key(), true );
	}

	public static function available() {
		return function_exists( 'openssl_encrypt' ) && function_exists( 'random_bytes' );
	}

	public static function encrypt( $plain ) {
		$plain = (string) $plain;
		if ( '' === $plain ) {
			return '';
		}
		if ( ! self::available() ) {
			return 'b64:' . base64_encode( $plain ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions -- fallback only when OpenSSL is missing; flagged in Health.
		}
		$iv     = random_bytes( 16 );
		$cipher = openssl_encrypt( $plain, 'aes-256-cbc', self::enc_key(), OPENSSL_RAW_DATA, $iv );
		if ( false === $cipher ) {
			return '';
		}
		$mac = hash_hmac( 'sha256', $iv . $cipher, self::mac_key(), true );
		return 'v1:' . base64_encode( $iv . $mac . $cipher ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}

	public static function decrypt( $stored ) {
		if ( ! is_string( $stored ) || '' === $stored ) {
			return '';
		}
		if ( 0 === strpos( $stored, 'b64:' ) ) {
			return (string) base64_decode( substr( $stored, 4 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		}
		if ( 0 !== strpos( $stored, 'v1:' ) || ! self::available() ) {
			return '';
		}
		$raw = base64_decode( substr( $stored, 3 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( false === $raw || strlen( $raw ) < 49 ) {
			return '';
		}
		$iv     = substr( $raw, 0, 16 );
		$mac    = substr( $raw, 16, 32 );
		$cipher = substr( $raw, 48 );
		if ( ! hash_equals( hash_hmac( 'sha256', $iv . $cipher, self::mac_key(), true ), $mac ) ) {
			return '';
		}
		$plain = openssl_decrypt( $cipher, 'aes-256-cbc', self::enc_key(), OPENSSL_RAW_DATA, $iv );
		return ( false === $plain ) ? '' : $plain;
	}
}
