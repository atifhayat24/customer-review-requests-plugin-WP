<?php
/**
 * Sends email via built-in SMTP, PHP mail, or WordPress wp_mail().
 *
 * SMTP and PHP mail use a private PHPMailer instance, so this plugin's settings never
 * change how the rest of the site sends email, and other mail plugins can't change ours.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_Mailer {

	/**
	 * @return array { ok: bool, error: string, debug: string }
	 */
	public static function send( $to, $subject, $html, $text, $unsub_url = '', $debug = false ) {
		$mode = IRR_Settings::get( 'mail_mode' );
		if ( 'wp_mail' === $mode ) {
			return self::send_wp_mail( $to, $subject, $html, $unsub_url );
		}
		return self::send_phpmailer( $mode, $to, $subject, $html, $text, $unsub_url, $debug );
	}

	private static function load_phpmailer() {
		if ( ! class_exists( '\PHPMailer\PHPMailer\PHPMailer' ) ) {
			require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
			require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
			require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
		}
	}

	private static function send_phpmailer( $mode, $to, $subject, $html, $text, $unsub_url, $debug ) {
		self::load_phpmailer();
		$log  = '';
		$pass = '';
		$user = '';
		$mail = new \PHPMailer\PHPMailer\PHPMailer( true );

		try {
			$mail->CharSet = 'UTF-8';
			$mail->XMailer = ' ';

			if ( 'smtp' === $mode ) {
				$host = IRR_Settings::get( 'smtp_host' );
				if ( ! $host ) {
					return array( 'ok' => false, 'error' => 'SMTP host is not set (Review Requests → Settings → Sending).', 'debug' => '' );
				}
				$mail->isSMTP();
				$mail->Host    = $host;
				$mail->Port    = absint( IRR_Settings::get( 'smtp_port' ) );
				$mail->Timeout = 20;
				// Cap how long we wait for any server reply (PHPMailer's default is 300 seconds),
				// so an unresponsive mail server can never stall the queue.
				$mail->getSMTPInstance()->Timelimit = 30;

				$enc = IRR_Settings::get( 'smtp_encryption' );
				if ( 'ssl' === $enc ) {
					$mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
				} elseif ( 'tls' === $enc ) {
					$mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
				} else {
					$mail->SMTPSecure  = '';
					$mail->SMTPAutoTLS = false;
				}

				if ( IRR_Settings::is_on( 'smtp_auth' ) ) {
					$user           = (string) IRR_Settings::get( 'smtp_user' );
					$pass           = IRR_Settings::smtp_password();
					$mail->SMTPAuth = true;
					$mail->Username = $user;
					$mail->Password = $pass;
					if ( '' === $pass ) {
						return array( 'ok' => false, 'error' => 'SMTP password is missing or could not be decrypted – re-enter it in Settings → Sending.', 'debug' => '' );
					}
				}

				if ( $debug ) {
					$mail->SMTPDebug   = \PHPMailer\PHPMailer\SMTP::DEBUG_SERVER;
					$mail->Debugoutput = function ( $str ) use ( &$log ) {
						$log .= rtrim( (string) $str ) . "\n";
					};
				}
			} else {
				$mail->isMail();
			}

			$mail->setFrom( IRR_Settings::from_email(), IRR_Settings::from_name(), true );
			$reply = IRR_Settings::get( 'reply_to' );
			if ( is_email( $reply ) ) {
				$mail->addReplyTo( $reply, IRR_Settings::from_name() );
			}
			$mail->addAddress( $to );
			$mail->Subject = $subject;
			$mail->isHTML( true );
			$mail->Body    = $html;
			$mail->AltBody = $text;

			if ( $unsub_url ) {
				$mail->addCustomHeader( 'List-Unsubscribe', '<' . esc_url_raw( $unsub_url ) . '>' );
				$mail->addCustomHeader( 'List-Unsubscribe-Post', 'List-Unsubscribe=One-Click' );
			}

			$mail->send();
			return array( 'ok' => true, 'error' => '', 'debug' => self::mask( $log, $user, $pass ) );

		} catch ( \PHPMailer\PHPMailer\Exception $e ) {
			$err = $mail->ErrorInfo ? $mail->ErrorInfo : $e->getMessage();
			return array( 'ok' => false, 'error' => self::mask( $err, $user, $pass ), 'debug' => self::mask( $log, $user, $pass ) );
		} catch ( \Throwable $e ) {
			return array( 'ok' => false, 'error' => self::mask( $e->getMessage(), $user, $pass ), 'debug' => self::mask( $log, $user, $pass ) );
		}
	}

	private static function send_wp_mail( $to, $subject, $html, $unsub_url ) {
		$error    = '';
		$catcher  = function ( $wp_error ) use ( &$error ) {
			if ( is_wp_error( $wp_error ) ) {
				$error = $wp_error->get_error_message();
			}
		};
		$from     = IRR_Settings::from_email();
		$headers  = array( 'Content-Type: text/html; charset=UTF-8' );
		if ( is_email( $from ) ) {
			$headers[] = 'From: ' . IRR_Settings::from_name() . ' <' . $from . '>';
		}
		$reply = IRR_Settings::get( 'reply_to' );
		if ( is_email( $reply ) ) {
			$headers[] = 'Reply-To: ' . $reply;
		}
		if ( $unsub_url ) {
			$headers[] = 'List-Unsubscribe: <' . esc_url_raw( $unsub_url ) . '>';
			$headers[] = 'List-Unsubscribe-Post: List-Unsubscribe=One-Click';
		}

		add_action( 'wp_mail_failed', $catcher );
		$ok = wp_mail( $to, $subject, $html, $headers );
		remove_action( 'wp_mail_failed', $catcher );

		return array(
			'ok'    => (bool) $ok,
			'error' => $ok ? '' : ( $error ? $error : 'wp_mail() returned false.' ),
			'debug' => '',
		);
	}

	/** Remove credentials from any error or debug output. */
	private static function mask( $text, $user, $pass ) {
		$text = (string) $text;
		$pass = (string) $pass;
		$user = (string) $user;
		$hide = array();
		if ( '' !== $pass ) {
			$hide[] = $pass;
			$hide[] = base64_encode( $pass ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
			$hide[] = base64_encode( "\0" . $user . "\0" . $pass ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		}
		if ( '' !== $user ) {
			$hide[] = base64_encode( $user ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		}
		return $hide ? str_replace( $hide, '********', $text ) : $text;
	}
}
