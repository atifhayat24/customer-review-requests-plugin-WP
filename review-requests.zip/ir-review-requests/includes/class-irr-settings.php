<?php
/**
 * Settings: defaults, access, sanitisation.
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

class IRR_Settings {

	const OPTION = 'irr2_settings';
	const GROUP  = 'irr2_settings_group';

	private static $cache = null;

	public static function init() {
		add_action( 'add_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
		add_action( 'update_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
	}

	public static function defaults() {
		return array(
			// General.
			'enabled'            => 'no',
			'trigger_status'     => 'completed',
			'delay_value'        => 7,
			'delay_unit'         => 'days',
			'cooldown_days'      => 60,

			// Review platforms.
			'tp_enabled'         => 'no',
			'tp_url'             => '',
			'g_enabled'          => 'no',
			'g_url'              => '',
			'custom_enabled'     => 'no',
			'custom_label'       => 'Facebook',
			'custom_url'         => '',
			'products_enabled'   => 'no',
			'products_max'       => 3,

			// Email content.
			'subject'            => 'How did we do, {first_name}?',
			'heading'            => 'How did we do?',
			'message'            => "Your order #{order_number} should have arrived by now, and we hope you love it.\n\nWould you mind taking a minute to share your experience? Honest reviews help other shoppers decide, and they mean a lot to us as a small business.",
			'button_text'        => 'Review us on {platform}',
			'button_colour'      => '#00b67a',
			'track_clicks'       => 'yes',

			// Reminder.
			'reminder_enabled'   => 'no',
			'reminder_value'     => 5,
			'reminder_unit'      => 'days',
			'reminder_subject'   => 'Quick reminder: how was your order, {first_name}?',
			'reminder_heading'   => 'We\'d love your feedback',
			'reminder_message'   => "Just a quick reminder – if you have a moment, we'd really appreciate a short review of your order #{order_number}.\n\nIt only takes a minute and really helps other shoppers.",

			// Sending.
			'mail_mode'          => 'php',
			'from_email'         => '',
			'from_name'          => '',
			'reply_to'           => '',
			'smtp_host'          => '',
			'smtp_port'          => 465,
			'smtp_encryption'    => 'ssl',
			'smtp_auth'          => 'yes',
			'smtp_user'          => '',
			'smtp_pass'          => '',
			'batch_size'         => 20,
			'max_attempts'       => 5,

			// Data.
			'log_retention_days' => 365,
			'delete_data'        => 'no',
		);
	}

	public static function flush() {
		self::$cache = null;
	}

	public static function all() {
		if ( null === self::$cache ) {
			$saved = get_option( self::OPTION, array() );
			$saved = is_array( $saved ) ? $saved : array();
			// Settings saved by 2.0.x used whole days.
			if ( ! isset( $saved['delay_value'] ) && isset( $saved['delay_days'] ) ) {
				$saved['delay_value'] = absint( $saved['delay_days'] );
				$saved['delay_unit']  = 'days';
			}
			if ( ! isset( $saved['reminder_value'] ) && isset( $saved['reminder_days'] ) ) {
				$saved['reminder_value'] = absint( $saved['reminder_days'] );
				$saved['reminder_unit']  = 'days';
			}
			self::$cache = wp_parse_args( $saved, self::defaults() );
		}
		return self::$cache;
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	public static function units() {
		return array(
			'minutes' => __( 'minutes', 'ir-review-requests' ),
			'hours'   => __( 'hours', 'ir-review-requests' ),
			'days'    => __( 'days', 'ir-review-requests' ),
		);
	}

	/** Convert a value + unit setting pair into seconds (capped at 90 days). */
	public static function seconds( $value_key, $unit_key ) {
		$mult = array(
			'minutes' => MINUTE_IN_SECONDS,
			'hours'   => HOUR_IN_SECONDS,
			'days'    => DAY_IN_SECONDS,
		);
		$unit = self::get( $unit_key );
		$unit = isset( $mult[ $unit ] ) ? $unit : 'days';
		return min( 90 * DAY_IN_SECONDS, absint( self::get( $value_key ) ) * $mult[ $unit ] );
	}

	public static function describe( $value_key, $unit_key ) {
		$units = self::units();
		$unit  = self::get( $unit_key );
		return absint( self::get( $value_key ) ) . ' ' . ( isset( $units[ $unit ] ) ? $units[ $unit ] : 'days' );
	}

	public static function is_on( $key ) {
		return 'yes' === self::get( $key );
	}

	public static function from_email() {
		$e = self::get( 'from_email' );
		if ( ! is_email( $e ) ) {
			$e = get_option( 'woocommerce_email_from_address' );
		}
		if ( ! is_email( $e ) ) {
			$e = get_option( 'admin_email' );
		}
		return sanitize_email( $e );
	}

	public static function from_name() {
		$n = self::get( 'from_name' );
		if ( '' === trim( (string) $n ) ) {
			$n = get_option( 'woocommerce_email_from_name', get_bloginfo( 'name' ) );
		}
		return trim( preg_replace( '/[\r\n\t]+/', ' ', wp_strip_all_tags( (string) $n ) ) );
	}

	/** SMTP password: a wp-config constant wins, otherwise the encrypted stored value. */
	public static function smtp_password() {
		if ( defined( 'IRR_SMTP_PASSWORD' ) ) {
			return (string) IRR_SMTP_PASSWORD;
		}
		return IRR_Crypto::decrypt( (string) self::get( 'smtp_pass' ) );
	}

	public static function status_choices() {
		$choices = array();
		if ( function_exists( 'wc_get_order_statuses' ) ) {
			$excluded = array( 'pending', 'failed', 'cancelled', 'refunded', 'on-hold', 'checkout-draft' );
			foreach ( wc_get_order_statuses() as $key => $label ) {
				$slug = ( 0 === strpos( $key, 'wc-' ) ) ? substr( $key, 3 ) : $key;
				if ( ! in_array( $slug, $excluded, true ) ) {
					$choices[ $slug ] = $label;
				}
			}
		}
		if ( ! $choices ) {
			$choices = array(
				'completed'  => 'Completed',
				'processing' => 'Processing',
			);
		}
		return $choices;
	}

	/**
	 * Enabled review platforms, in display order.
	 *
	 * @return array key => array( 'label' => ..., 'url' => ... )
	 */
	public static function platforms() {
		$s   = self::all();
		$out = array();
		if ( 'yes' === $s['tp_enabled'] && $s['tp_url'] ) {
			$out['tp'] = array( 'label' => 'Trustpilot', 'url' => $s['tp_url'] );
		}
		if ( 'yes' === $s['g_enabled'] && $s['g_url'] ) {
			$out['g'] = array( 'label' => 'Google', 'url' => $s['g_url'] );
		}
		if ( 'yes' === $s['custom_enabled'] && $s['custom_url'] ) {
			$out['cu'] = array( 'label' => $s['custom_label'] ? $s['custom_label'] : 'us', 'url' => $s['custom_url'] );
		}
		return $out;
	}

	public static function has_review_target() {
		return (bool) self::platforms() || self::is_on( 'products_enabled' );
	}

	/* ---------- Sanitisation ---------- */

	public static function sanitize( $input ) {
		$d        = self::defaults();
		$in       = is_array( $input ) ? $input : array();
		$existing = get_option( self::OPTION, array() );
		$existing = is_array( $existing ) ? $existing : array();
		$out      = array();

		$yes_no = array( 'enabled', 'tp_enabled', 'g_enabled', 'custom_enabled', 'products_enabled', 'track_clicks', 'reminder_enabled', 'smtp_auth', 'delete_data' );
		foreach ( $yes_no as $k ) {
			$out[ $k ] = ( isset( $in[ $k ] ) && 'yes' === $in[ $k ] ) ? 'yes' : 'no';
		}

		$ints = array(
			'delay_value'        => array( 0, 999 ),
			'cooldown_days'      => array( 0, 365 ),
			'products_max'       => array( 1, 10 ),
			'reminder_value'     => array( 1, 999 ),
			'smtp_port'          => array( 1, 65535 ),
			'batch_size'         => array( 1, 100 ),
			'max_attempts'       => array( 1, 10 ),
			'log_retention_days' => array( 0, 3650 ),
		);
		foreach ( $ints as $k => $range ) {
			$v         = isset( $in[ $k ] ) ? absint( $in[ $k ] ) : $d[ $k ];
			$out[ $k ] = max( $range[0], min( $range[1], $v ) );
		}

		foreach ( array( 'delay_unit', 'reminder_unit' ) as $k ) {
			$u         = isset( $in[ $k ] ) ? sanitize_key( $in[ $k ] ) : '';
			$out[ $k ] = array_key_exists( $u, self::units() ) ? $u : 'days';
		}

		$status                = isset( $in['trigger_status'] ) ? sanitize_key( $in['trigger_status'] ) : '';
		$out['trigger_status'] = array_key_exists( $status, self::status_choices() ) ? $status : $d['trigger_status'];

		foreach ( array( 'tp_url', 'g_url', 'custom_url' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? esc_url_raw( trim( (string) $in[ $k ] ), array( 'https', 'http' ) ) : '';
		}

		foreach ( array( 'custom_label', 'subject', 'heading', 'button_text', 'reminder_subject', 'reminder_heading' ) as $k ) {
			$v         = isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : '';
			$out[ $k ] = ( '' !== $v ) ? $v : $d[ $k ];
		}

		foreach ( array( 'message', 'reminder_message' ) as $k ) {
			$v         = isset( $in[ $k ] ) ? sanitize_textarea_field( $in[ $k ] ) : '';
			$out[ $k ] = ( '' !== trim( $v ) ) ? $v : $d[ $k ];
		}

		$colour               = isset( $in['button_colour'] ) ? sanitize_hex_color( $in['button_colour'] ) : '';
		$out['button_colour'] = $colour ? $colour : $d['button_colour'];

		// Sending.
		$mode             = isset( $in['mail_mode'] ) ? sanitize_key( $in['mail_mode'] ) : 'php';
		$out['mail_mode'] = in_array( $mode, array( 'smtp', 'php', 'wp_mail' ), true ) ? $mode : 'php';

		$enc                    = isset( $in['smtp_encryption'] ) ? sanitize_key( $in['smtp_encryption'] ) : 'ssl';
		$out['smtp_encryption'] = in_array( $enc, array( 'ssl', 'tls', 'none' ), true ) ? $enc : 'ssl';

		$host             = isset( $in['smtp_host'] ) ? strtolower( trim( sanitize_text_field( $in['smtp_host'] ) ) ) : '';
		$out['smtp_host'] = preg_match( '/^[a-z0-9.\-]+$/', $host ) ? $host : '';

		$out['smtp_user']  = isset( $in['smtp_user'] ) ? trim( sanitize_text_field( $in['smtp_user'] ) ) : '';
		$out['from_email'] = isset( $in['from_email'] ) ? sanitize_email( $in['from_email'] ) : '';
		$out['reply_to']   = isset( $in['reply_to'] ) ? sanitize_email( $in['reply_to'] ) : '';
		$out['from_name']  = isset( $in['from_name'] ) ? sanitize_text_field( $in['from_name'] ) : '';

		// Password: only changes when a new one is typed or "clear" is ticked. Never echoed back.
		$out['smtp_pass'] = isset( $existing['smtp_pass'] ) ? $existing['smtp_pass'] : '';
		// WordPress runs this callback twice when the option is first created; keep the value encrypted on the first pass.
		if ( isset( $in['smtp_pass'] ) && ! isset( $in['smtp_pass_new'] ) && is_string( $in['smtp_pass'] ) && preg_match( '/^(v1|b64):/', $in['smtp_pass'] ) ) {
			$out['smtp_pass'] = $in['smtp_pass'];
		}
		if ( ! empty( $in['smtp_pass_clear'] ) ) {
			$out['smtp_pass'] = '';
		} elseif ( isset( $in['smtp_pass_new'] ) && '' !== (string) $in['smtp_pass_new'] ) {
			$out['smtp_pass'] = IRR_Crypto::encrypt( (string) $in['smtp_pass_new'] );
		}

		// Validation.
		$has_target = ( 'yes' === $out['tp_enabled'] && $out['tp_url'] )
			|| ( 'yes' === $out['g_enabled'] && $out['g_url'] )
			|| ( 'yes' === $out['custom_enabled'] && $out['custom_url'] )
			|| 'yes' === $out['products_enabled'];

		if ( 'yes' === $out['enabled'] && ! $has_target ) {
			$out['enabled'] = 'no';
			add_settings_error( self::OPTION, 'irr_no_target', __( 'Turn on at least one review platform (with its link) before enabling. Review requests are OFF.', 'ir-review-requests' ), 'error' );
		}
		if ( 'smtp' === $out['mail_mode'] && '' === $out['smtp_host'] ) {
			add_settings_error( self::OPTION, 'irr_no_host', __( 'SMTP is selected but the SMTP host is empty or invalid. Emails will fail until it is set.', 'ir-review-requests' ), 'error' );
		}
		if ( $out['from_email'] && ! is_email( $out['from_email'] ) ) {
			$out['from_email'] = '';
		}

		return $out;
	}
}
