<?php
/**
 * Plugin Name:          IR Review Requests for WooCommerce
 * Description:          Automatically asks customers for a review (Trustpilot, Google, any other platform or your own product reviews) a set number of days after their order is completed. Includes built-in SMTP, a retrying email queue, reminders, click tracking, unsubscribe handling and a health check.
 * Version:              2.2.0
 * Requires at least:    5.8
 * Requires PHP:         7.2
 * Author:               Insightful Reach
 * License:              GPL-2.0-or-later
 * License URI:          https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:          ir-review-requests
 * Domain Path:          /languages
 * Update URI:           false
 * WC requires at least: 6.0
 *
 * @package IR_Review_Requests
 */

defined( 'ABSPATH' ) || exit;

// Never load two copies at once.
if ( defined( 'IRR_VERSION' ) ) {
	return;
}

define( 'IRR_VERSION', '2.2.0' );
define( 'IRR_FILE', __FILE__ );
define( 'IRR_DIR', plugin_dir_path( __FILE__ ) );
define( 'IRR_URL', plugin_dir_url( __FILE__ ) );

require_once IRR_DIR . 'includes/class-irr-settings.php';
require_once IRR_DIR . 'includes/class-irr-crypto.php';
require_once IRR_DIR . 'includes/class-irr-db.php';
require_once IRR_DIR . 'includes/class-irr-mailer.php';
require_once IRR_DIR . 'includes/class-irr-email.php';
require_once IRR_DIR . 'includes/class-irr-queue.php';
require_once IRR_DIR . 'includes/class-irr-public.php';
require_once IRR_DIR . 'includes/class-irr-admin.php';
require_once IRR_DIR . 'includes/class-irr-plugin.php';

register_activation_hook( __FILE__, array( 'IRR_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'IRR_Plugin', 'deactivate' ) );

IRR_Plugin::init();
