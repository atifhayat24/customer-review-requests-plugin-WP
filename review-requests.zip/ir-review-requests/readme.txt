=== IR Review Requests for WooCommerce ===
Contributors: insightfulreach
Tags: woocommerce, reviews, trustpilot, google reviews, review request
Requires at least: 5.8
Requires PHP: 7.2
Stable tag: 2.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically emails customers asking for a review a set number of days after their order is completed.

== Description ==

* Review platforms: Trustpilot, Google, any other site (Facebook, Feefo, Yell…) and your own WooCommerce product reviews – switch each on or off.
* Sends X days after an order reaches a status you choose (Completed by default).
* Optional reminder, skipped automatically if the customer already clicked or reviewed.
* Built-in SMTP (cPanel / hosting email), PHP mail, or WordPress default – only affects review emails.
* Email queue with automatic retries (15 min, 1 h, 6 h, daily) and recovery of stuck sends.
* Dashboard, full email list, activity log, CSV export, click tracking.
* Unsubscribe link with one-click unsubscribe support (Gmail / Yahoo requirement).
* Tools & health: checks your setup, sends test emails with the SMTP conversation, previews, "ask past customers".
* Uses your WooCommerce email design. Compatible with HPOS.

== Installation ==

1. Plugins → Add New → Upload Plugin → choose the zip → Install → Activate.
2. You are taken to Review Requests. Open Settings, add your review links and SMTP details, save.
3. Tools & health → Send test email.
4. Settings → tick "Enabled" → Save.

== Frequently Asked Questions ==

= Where is the SMTP password stored? =
Encrypted in the database using your site's secret keys. Alternatively add `define( 'IRR_SMTP_PASSWORD', 'your-password' );` to wp-config.php.

= Does it change my other site emails? =
No. The SMTP settings are used only for review request emails.

= What happens to emails if my mail server is down? =
They are retried automatically. After the maximum attempts they are marked Failed and can be retried from the Emails screen.

== Changelog ==

= 2.2.0 =
* Send to previous customers: all time or a chosen period, one email per customer, runs in the background with progress, stop and cancel.

= 2.1.0 =
* Delay and reminder can be set in minutes, hours or days.
* Backup runner: due emails are sent on normal page visits if WP-Cron / Action Scheduler is late.
* Emails screen shows when each waiting email is due; health check explains how the queue last ran.

= 2.0.0 =
* Complete rebuild: multi-file plugin, top-level admin menu, email queue with retries, built-in SMTP, reminders, multiple review platforms, product reviews, activity log, health checks.
